package com.cg.testseriesapplicationsb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.testseriesapplicationsb.dto.Candidate;
import com.cg.testseriesapplicationsb.dto.Test;

/*
 * This is Candidate repository interface which extends JPA repository of bean Candidate..
 *it includes  find by id method
 * */
public interface CandidateRepository extends JpaRepository<Candidate, Integer>{

	
	public Candidate findByid(int id);
}

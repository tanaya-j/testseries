package com.cg.testseriesapplicationsb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;




/*This is main class which initializes the spring boot*/

/*Spring Boot Application annotation that wraps 3other annotations which are @Configuration ,@Component scan 
and @Enable Auto configuration
*/
@SpringBootApplication
@ComponentScan("com.cg.testseriesapplicationsb")//scans all the beans which falls under the given package
public class TestSeriesApplicationSbApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(TestSeriesApplicationSbApplication.class, args);//initializes application
		System.out.println("welcome");
	}

	/* @Override
	protected void configureValidatingRepositoryEventListener(ValidatingRepositoryEventListener validatingListener) 
    {
	    validatingListener.addValidator("beforeCreate", new CandidateValidate());
    }*/
}


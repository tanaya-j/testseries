package com.cg.testseriesapplicationsb.exception;

public class TestNotFoundException extends RuntimeException {

	public TestNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	

	public TestNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}

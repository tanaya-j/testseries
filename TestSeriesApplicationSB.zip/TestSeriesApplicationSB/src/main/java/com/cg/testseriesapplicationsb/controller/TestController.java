package com.cg.testseriesapplicationsb.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.testseriesapplicationsb.dto.Assigner;
import com.cg.testseriesapplicationsb.dto.Candidate;
import com.cg.testseriesapplicationsb.dto.Question;
import com.cg.testseriesapplicationsb.dto.Test;
import com.cg.testseriesapplicationsb.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationsb.exception.TestNotFoundException;
import com.cg.testseriesapplicationsb.service.CandidateService;
import com.cg.testseriesapplicationsb.service.TestAssignerService;
import com.cg.testseriesapplicationsb.service.TestService;

/*This a controller class*/

@RestController
@RequestMapping("/test")
public class TestController {
	@Autowired
	TestService tservice;
	@Autowired
	CandidateService cservice;
	@Autowired
	TestAssignerService aservice;
	
	 /* This method map to http://localhost:9098/test/addtest
	 * @param Model Attribute Test
	 * @return response entity
	 * 
    * */ 
	
	@RequestMapping(method=RequestMethod.POST,value="/addtest" )
	public ResponseEntity<Test> addTest(@ModelAttribute Test test){
			
	
		Test t1=tservice.createMyTest(test);
		return new ResponseEntity(t1,HttpStatus.OK);
	}
	
	 /* This method map to http://localhost:9098/test/addCandidate
		 * @param Model Attribute Candidate
		 * @return response entity
		 * 
	 * */ 
	@RequestMapping(method=RequestMethod.POST,value="/addCandidate" )
	public ResponseEntity<Candidate> addCandidate(@ModelAttribute Candidate candidate){
			
		Candidate c=cservice.addCandidate(candidate);
		return new ResponseEntity(c,HttpStatus.OK);
	}
	
	/* This method map to http://localhost:9098/test/searchTest
	 * @param Model Attribute Test
	 * @return response entity
	 * 
   * */ 
	@RequestMapping(method=RequestMethod.POST,value="/searchTest")
	public ResponseEntity<Test>search(@ModelAttribute Test test) {
	Test t= tservice.searchTestByName(test.getName());
	/*if(t==null)
	{
		return new ResponseEntity("Test not added",HttpStatus.NOT_FOUND);
	}*/
	return new ResponseEntity(t,HttpStatus.OK);
	}
	
	
	/* This method map to http://localhost:9098/test/assignTest
	 * @param Model Attribute assigner
	 * @return response entity
	 * 
   * */ 
	@RequestMapping(method=RequestMethod.POST,value="/assignTest")
	public ResponseEntity<Assigner>assign(@ModelAttribute Assigner assigner) {
		assigner.setDate(new Timestamp(System.currentTimeMillis()));
		Test tid=tservice.searchTestById(assigner.getTest().getId());
		if(tid==null) {
			return new ResponseEntity("Test with this id not found..!!",HttpStatus.NOT_FOUND);
		}
		Candidate cid=cservice.searchById(assigner.getCandidate().getId());
		if(cid==null) {
			return new ResponseEntity("Candidate with this id not found..!!",HttpStatus.NOT_FOUND);
		}
	Assigner a=aservice.assignTestToCandidate(assigner);
	if(a==null)
	{
		return new ResponseEntity("Test not assigned",HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity(a,HttpStatus.OK);
	}
	
	/* This method is used to handle Candidate Exception
	 * @param CandidateNotFoundException
	 * @return response entity
	 * 
 * */ 
    @ExceptionHandler({CandidateNotFoundException.class})
		public ResponseEntity handleCandidateException(CandidateNotFoundException be) {

    	return new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);
	    }
	
   
    /* This method is used to handle Test Exception
	 * @param CandidateNotFoundException
	 * @return response entity
	 * 
 * */ 
    @ExceptionHandler({TestNotFoundException.class})
	public ResponseEntity handleTestException(TestNotFoundException be) {
    	return new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);
		
	}  
}



package com.cg.testseriesapplicationsb.service;

import javax.tools.DocumentationTool.DocumentationTask;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationsb.dto.Candidate;
import com.cg.testseriesapplicationsb.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationsb.repository.CandidateRepository;


/*
 * This class is a implementation of candidate service interface.
 * It includes add candidate and search candidate by id methods.
 * last Modified 15/05/2019  Author:Tanaya Jadhav 
*/
@Transactional
@Service
public class CandidateServiceImp implements CandidateService{
	@Autowired
	CandidateRepository dao;
	static int candidateId=1;
 
		static final Logger logger = Logger.getLogger(CandidateServiceImp.class); 
		 

	
	
	/*This method is used to add candidates 
	 * @param: candidate
	 * @return: candidate  
	 last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Candidate addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
	  PropertyConfigurator.configure("D:\\NewWorkspace\\TestSeriesApplicationSB\\src\\main\\resources\\log4j.properties");
      candidate.setId(candidateId);
      candidateId++;
      logger.info("ADDING CANDIDATES..!!!!");
     return	dao.save(candidate);
	}

	
	/*This method is used to search candidate by id
	 * @param: id
	 * @return: candidate with that id   
	 *last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	
	public Candidate searchById(int id) {
		PropertyConfigurator.configure("D:\\NewWorkspace\\TestSeriesApplicationSB\\src\\main\\resources\\log4j.properties");
		Candidate c= dao.findByid(id);
		if(c==null) {
			throw new CandidateNotFoundException("Candidate not found..!!!");
		}
		 logger.info("SEARCHING CANDIDATES..!!!!");
		return c;
	}

}

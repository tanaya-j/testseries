package com.cg.testseriesapplicationsb.exception;

public class CandidateNotFoundException extends RuntimeException {

	public CandidateNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public CandidateNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}

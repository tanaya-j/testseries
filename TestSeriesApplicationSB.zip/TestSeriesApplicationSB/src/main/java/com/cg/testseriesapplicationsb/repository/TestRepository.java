package com.cg.testseriesapplicationsb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.testseriesapplicationsb.dto.Test;

/*
 * This is Test repository Interface which extends JPA repository of bean test..
 * it includes find by name and find by id methods
 * */

public interface TestRepository extends JpaRepository<Test,Integer> {

	public Test findByName(String name);
	public Test findByid(int id);
	
}

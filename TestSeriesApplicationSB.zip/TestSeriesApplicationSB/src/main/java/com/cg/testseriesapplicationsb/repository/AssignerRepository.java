package com.cg.testseriesapplicationsb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.testseriesapplicationsb.dto.Assigner;

public interface AssignerRepository extends JpaRepository<Assigner, Integer> {

}

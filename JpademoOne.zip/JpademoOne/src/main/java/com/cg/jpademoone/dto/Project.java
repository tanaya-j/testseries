package com.cg.jpademoone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

public class Project {

	@Id
	@Column(name="proj_id")
	private int id;
	@Column(name="proj_name")
	private String name;
	
	
public Project() {}


public Project(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


@Override
public String toString() {
	return "Project [id=" + id + ", name=" + name + "]";
}


	
}

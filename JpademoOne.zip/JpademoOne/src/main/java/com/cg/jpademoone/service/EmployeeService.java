package com.cg.jpademoone.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.jpademoone.dto.Employee;
import com.cg.jpademoone.dto.Project;

public class EmployeeService {
 
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoemployeemanagement");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tx= em.getTransaction();
	
	
	public Employee add(int id,String name,double salary,Project proj) {
		Employee employee=new Employee();
		Project project=new Project();
		
		employee.setId(id);
		employee.setName(name);
		employee.setSalary(salary);
		employee.setProj(project);
		tx.begin();
		em.persist(employee);
		tx.commit();
		
		
		return employee;
	}
	
	
	public Employee update(int eid,String ename,double salary,String pname) {
		Employee employee =em.find(Employee.class, eid);
		if(employee!=null) {
			Project project=em.find(Project.class, employee.getProj().getId());
	    	project.setName(pname);
	    	employee.setName(ename);
	    	employee.setSalary(salary);
	    	employee.setProj(project);
	    	tx.begin();
	    	em.persist(employee);
	    	em.persist(project);
	    	tx.commit();
		}
		return employee;
	}
	
	public Employee remove(int id) {
		Employee employee=em.find(Employee.class, id);
		
		if(employee!=null){
			tx.begin();
			em.remove(employee);
			tx.commit();
			}
		return employee;
	}
}

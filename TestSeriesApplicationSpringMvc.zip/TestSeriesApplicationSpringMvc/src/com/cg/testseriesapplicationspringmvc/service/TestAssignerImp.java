package com.cg.testseriesapplicationspringmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.repository.TestAssignerRepository;

@Service
public class TestAssignerImp implements TestAssignerService{

	
	@Autowired
	TestAssignerRepository assignerDao;
	@Override
	public Assigner assignTestToCandidate(Assigner assigner) {
		// TODO Auto-generated method stub
		return assignerDao.save(assigner) ;
	}

}

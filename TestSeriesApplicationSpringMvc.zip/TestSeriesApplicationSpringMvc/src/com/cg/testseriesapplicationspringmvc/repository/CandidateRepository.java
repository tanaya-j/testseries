package com.cg.testseriesapplicationspringmvc.repository;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;

public interface CandidateRepository {
	public Candidate saveCandidate(Candidate candidate);
	public Candidate findById(int id);
}

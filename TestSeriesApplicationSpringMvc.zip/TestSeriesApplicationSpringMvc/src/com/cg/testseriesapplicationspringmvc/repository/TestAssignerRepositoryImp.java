package com.cg.testseriesapplicationspringmvc.repository;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.util.DBUtilAssigner;

@Repository("AssignerRepository")
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	@Override
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
		 DBUtilAssigner.assigner.add(assigner);
			return assigner;
	}

}

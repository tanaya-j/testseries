package com.cg.testseriesapplicationspringmvc.repository;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.util.DbUtilTest;

@Repository
public class TestRepositoryImp implements TestRepository{

	@Override
	public Test saveTest(Test test) {
		// TODO Auto-generated method stub
		DbUtilTest.myTestList.add(test);
		return test;
	}

	@Override
	public Test findByName(String testName) {
		// TODO Auto-generated method stub
		for(Test myTestName: DbUtilTest.myTestList)
			if(myTestName.getName().equals(testName)) {
				return myTestName;
			}
			
	      	return null;
	}

}

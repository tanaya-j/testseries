package com.cg.testseriesapplicationspringmvc.repository;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.util.DBUtilCandidate;

@Repository("CandidateRepository")
public class CandidateRepositoryImp implements CandidateRepository {

	@Override
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		DBUtilCandidate.myCandidates.add(candidate);
		return candidate;
	}

	@Override
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		for (Candidate candidate : DBUtilCandidate.myCandidates) 
			if(candidate.getId()==id) {
			
				return  candidate;
			}
			return null;
	}

}

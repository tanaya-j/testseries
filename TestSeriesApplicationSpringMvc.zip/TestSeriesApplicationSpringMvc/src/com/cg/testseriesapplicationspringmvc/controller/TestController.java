package com.cg.testseriesapplicationspringmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController {

	
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";

	}

	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		//System.out.println("Logged in");
		if (user.equals("admin") && pass.equals("tanaya")) {
			return "listproduct";
		} else {
			return "error";

		}

	}
}

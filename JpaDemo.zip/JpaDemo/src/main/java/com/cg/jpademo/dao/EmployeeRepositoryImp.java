package com.cg.jpademo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.util.DbUtil;

public class EmployeeRepositoryImp implements EmployeeRepository{
	
	EntityManager em;
	public EmployeeRepositoryImp() {
		em =DbUtil.getConnection();
	}

	public void saveEmployee(Employee emp) {
		// TODO Auto-generated method stub
		em.persist(emp);
		em.getTransaction().commit();
	}

	public List<Employee> findBySalary(double low, double higher) {
		// TODO Auto-generated method stub
		Query query=em.createQuery("FROM Employee WHERE salary BETWEEN :below AND :high");
		query.setParameter("below", low);
		query.setParameter("high", higher);
		List<Employee> empList=query.getResultList();
		return empList;
	}

	public List<Employee> findByDepartmentName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}

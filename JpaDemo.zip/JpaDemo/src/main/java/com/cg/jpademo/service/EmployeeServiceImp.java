package com.cg.jpademo.service;

import java.util.List;

import com.cg.jpademo.dao.EmployeeRepository;
import com.cg.jpademo.dao.EmployeeRepositoryImp;
import com.cg.jpademo.dto.Employee;

public class EmployeeServiceImp implements EmployeeService {
	
	EmployeeRepository dao=null;
	
	public EmployeeServiceImp() {
		dao=new EmployeeRepositoryImp();
	}
			
			

	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		dao.saveEmployee(emp);
	}

	public List<Employee> searchBySalary(double low, double higher) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> searchByDepartmentName(String name) {
		// TODO Auto-generated method stub
		return dao.findByDepartmentName(name);
	}

	public List<Employee> searchByDate() {
		// TODO Auto-generated method stub
		return null;
	}

}

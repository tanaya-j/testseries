package com.cg.jpademo.ui;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.service.EmployeeService;
import com.cg.jpademo.service.EmployeeServiceImp;

public class MyMain {
static	EmployeeService services;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 services=new EmployeeServiceImp(); 
			
		
		Scanner scr=new Scanner(System.in);
		
		System.out.println("Enter the employee id:");
		int id=scr.nextInt();
		System.out.println("Enter the employee name:");
		String name=scr.next();
		System.out.println("Enter the employee salary:");
		double salary=scr.nextDouble();
		//System.out.println("Enter the employee type:");
		boolean type=true;
		System.out.println("Enter the date of joining:");
		String date=scr.next();
		
		System.out.println("Enter the department id:");
		int did=scr.nextInt();
		System.out.println("Enter the department name:");
		String dname=scr.next();
		
		Department dept=new Department();
		dept.setId(did);
		dept.setName(dname);
		
		Address add=new Address();
		add.setCity("Pune");
		add.setState("MH");
		add.setPincode(411045);
		
		Employee emp= new Employee();
		emp.setId(id);
		emp.setName(name);
		emp.setSalary(salary);
		emp.setAddr(add);
		emp.setDateOfJoining(new Date());
		emp.setDept(dept);
		
		//services.addEmployee(emp);
		
		List<Employee> myList= services.searchBySalary(2000, 25000);
		for(Employee employee: myList) {
			System.out.println("Employee id:"+employee.getId());
			System.out.println("Employe  name:"+employee.getName());
			System.out.println("EMployee salary:"+employee.getSalary());
			System.out.println("Employee department"+employee.getDept());
			System.out.println("Employee address:"+employee.getAddr());
			
			}
			
		}
	}



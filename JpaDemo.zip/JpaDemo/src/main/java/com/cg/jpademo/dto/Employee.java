package com.cg.jpademo.dto;

import java.sql.Time;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="employeedb")
public class Employee {

	@Id 
	@Column(name="emp_id")
	private int id;
	@Column(name="emp_name")
	private String name;
	@Column(name="emp_salary")
	private double salary;
	@Column(name="emp_type")
	private boolean type;
	@Column(name="joining")
	@Temporal(TemporalType.DATE)
    private	Date dateOfJoining;
	@Embedded
	private Address addr;	
   
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="dept_id")
	private Department dept;
	
	public Employee() {}
	public Employee(int id, String name, double salary, boolean type, Date dateOfJoining, Address addr,
			Department dept) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.type = type;
		this.dateOfJoining = dateOfJoining;
		this.addr = addr;
		this.dept = dept;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public boolean isType() {
		return type;
	}

	public void setType(boolean type) {
		this.type = type;
	}
	
	public Date getDateOfJoining() {
		return dateOfJoining;
	}



	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	public Department getDept() {
		return dept;
	}

    public void setDept(Department dept) {
		this.dept = dept;
	}


    public Address getAddr() {
		return addr;
	}

    public void setAddr(Address addr) {
		this.addr = addr;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", type=" + type + ", dateOfJoining="
				+ dateOfJoining + ", addr=" + addr + ", dept=" + dept + "]";
	}

}

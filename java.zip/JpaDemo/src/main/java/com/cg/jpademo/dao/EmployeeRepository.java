package com.cg.jpademo.dao;

import java.util.List;

import com.cg.jpademo.dto.Employee;

public interface EmployeeRepository {
	public void saveEmployee(Employee emp);
	public List<Employee> findBySalary(double low,double higher);
	public List<Employee> findByDepartmentName(String name);
}

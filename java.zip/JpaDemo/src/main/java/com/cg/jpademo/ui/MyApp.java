package com.cg.jpademo.ui;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;

public class MyApp {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoemployeemanagement");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		/*
		Employee emp=new Employee();
		emp.setId(105);
		emp.setName("sona");
		emp.setSalary(100000.00);
		emp.setType(true);
		emp.setDateOfJoining(new Date());
        em.persist(emp);
        

		Employee empOne=new Employee();
		empOne.setId(106);
		empOne.setName("yasha");
		empOne.setSalary(100000.00);
		empOne.setType(true);
		empOne.setDateOfJoining(new Date());
        em.persist(empOne);

		Employee empTwo=new Employee();
		empTwo.setId(107);
		empTwo.setName("aisha");
		empTwo.setSalary(100000.00);
		empTwo.setType(true);
		empTwo.setDateOfJoining(new Date());
        em.persist(empTwo);*/
      /* Address address=new Address();
       address.setCity("pune");
       address.setState("maharashtra");
       address.setPincode(411045);
		Employee empThree=new Employee();
        empThree.setId(108);
        empThree.setName("tana");
        empThree.setSalary(100000.00);
        empThree.setType(true);
        empThree.setDateOfJoining(new Date());
        empThree.setAddr(address);
        em.persist(empThree);*/
   
        Department dept=new Department();
        dept.setId(1);
        dept.setName("Java");
        

        Department deptOne=new Department();
        deptOne.setId(2);
        deptOne.setName(".Net");
         
        Address addressOne=new Address();
        addressOne.setCity("Pune");
        addressOne.setState("Maharashtra");
        addressOne.setPincode(411045);
 		 
         Employee empFour=new Employee();
         empFour.setId(101);
         empFour.setName("rutu");
         empFour.setSalary(10000.00);
         empFour.setType(true);
         empFour.setDateOfJoining(new Date());
         empFour.setAddr(addressOne);
         empFour.setDept(dept);
         
         
         Employee empThree=new Employee();
         empThree.setId(102);
         empThree.setName("sona");
         empThree.setSalary(100000.00);
         empThree.setType(true);
         empThree.setDateOfJoining(new Date());
         empThree.setAddr(addressOne);
         empThree.setDept(deptOne);
         
         Employee empTwo=new Employee();
         empTwo.setId(103);
         empTwo.setName("aish");
         empTwo.setSalary(100000.00);
         empTwo.setType(true);
         empTwo.setDateOfJoining(new Date());
         empTwo.setAddr(addressOne);
         empTwo.setDept(dept); 
    
       /*dept.getMyEmps().add(empTwo);
       dept.getMyEmps().add(empThree);
       dept.getMyEmps().add(empFour);*/
      /*   em.persist(dept);
         em.persist(deptOne);*/
         
         
         em.persist(empFour);
         em.persist(empThree);
         em.persist(empTwo);
       
        /*   Employee e=em.find(Employee.class,1);  
        
        System.out.println(" id = "+e.getId());  
        System.out.println(" Name = "+e.getName());  
        System.out.println(" Salary = "+e.getSalary());  
       
        e.setSalary(200000.0);  
        
        System.out.println("After Updation");  
        System.out.println("Student id = "+e.getId());  
        System.out.println("Student Name = "+e.getName());  
        System.out.println("Student Age = "+e.getSalary());  
        em.remove(e);  */
        em.getTransaction().commit();
        em.close();
	}

}

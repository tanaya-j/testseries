package com.cg.assign.dto;

import java.util.Scanner;

public class LabOne 
{
	
	public int calculateSum(int n) 
	{
        int sum=0;
	    //int count=1;
		
	    for(int i=0;i<=n;i++)
          {
		if(i % 3==0 || i % 5 ==0)
		   {
		     sum += i;
		   }
          }
		return sum;
	}	
		
	
	public static void main(String args[]) 
	{
		Scanner scr=new Scanner(System.in);
		System.out.println("enter the no of natural nos");
	    int n=scr.nextInt();
		LabOne sum = new LabOne();
		int s=sum.calculateSum(n);
		System.out.println(s);
		
	}
	
}
	
		/*int sum=0,n,count=1;
		
		Scanner scr=new Scanner(System.in);
		System.out.println("enter the no of natural nos");
	 n=scr.nextInt();
		
		for(int i=0;i<=n;i++)
		{
			if(n % 3==0 || n % 5 ==0)
			
		  {
			sum += count;
			count++;
		  }
		}
		System.out.println("sum is"+sum);
	}*/



package com.cg.assign.dto;

import java.util.Scanner;

public class LabThreeThree {
/*
	public int[] reverse(int a[],int n) {
		 int[] b = new int[n]; 
	        int j = n; 
	        for (int i = 0; i < n; i++) { 
	            b[j - 1] = a[i]; 
	            j = j - 1; 
	        } 
	  
	        printing the reversed array
	        System.out.println("Reversed array is: \n"); 
	        for (int k = 0; k < n; k++) { 
	            System.out.println(b[k]); 
	        }
			return a; 
	}

	public static void main(String[] args) {
		LabThreeThree s=new LabThreeThree();
		
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the no of elements in an array: ");
		int n=scr.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the elements in an array: ");
		 for(int i=0;i<n;i++) {
			 a[i]=scr.nextInt();
		 }
		 
		 int[] i=(s.reverse(a, n));
		 System.out.println(i);
     
	}*/
}

package com.cg.assign.dto;

public class LabThree {

	
	
}

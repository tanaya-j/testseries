package com.cg.assign.dto;

import java.util.Scanner;

public class LabThreeFour {
	
	 public static String count(String s) 
	    {
		
	      int count[]=new int[2];
		  int length=s.length();
		  
		  for (int i = 0; i < length; i++) 
	            count[s.charAt(i)]++; 
	  
	        
	        char ch[] = new char[s.length()]; 
	        for (int i = 0; i < length; i++) { 
	            ch[i] = s.charAt(i); 
	            int find = 0; 
	            for (int j = 0; j <= i; j++) { 
	  
	             
	                if (s.charAt(i) == ch[j])  
	                    find++;                 
	            } 
	  
	            if (find == 1)  
	                System.out.println("Number of Occurrence of " + 
	                 s.charAt(i) + " is:" + count[s.charAt(i)]);  
	        }return s;
	    }
	    // Driver method 
	    public static void main(String args[]) 
	    { 
	    	Scanner scr=new Scanner(System.in);
		    System.out.println("Enter the String: ");
		    String a=scr.next();
	        String s=count(a);
		    System.out.println(s);
	} 
}

package com.cg.assign.dto;

import java.util.Scanner;

public class LabTwo {
	
	
	
	
	
	public int calcDifference(int n) 
	{
		 int sum=0,sums=0,p=1;
	   	for(int i=0;i<=n;i++)
	   	{
	   		sum+=i*i;
	   		sums+=i;
	   	  p=sums*sums;
	   		
	   	}
	   	int reslt=sum-p;
	   	return reslt;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner scr=new Scanner(System.in);
		Scanner scr=new Scanner(System.in);
		System.out.println("enter the no of natural nos");
	    int n=scr.nextInt();
		LabTwo sum = new LabTwo();
		int s=sum.calcDifference(n);
		System.out.println(s);
		


	}

}

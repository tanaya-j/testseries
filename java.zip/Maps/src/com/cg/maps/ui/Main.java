package com.cg.maps.ui;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;



	
		// TODO Auto-generated method stub
            /*Map<Integer, String> myMap=new HashMap<Integer,String>();
            
            myMap.put(1, "A");
            myMap.put(null, "B");
            myMap.put(null, "C");
            
            System.out.println(myMap);*/
		
	
			// public static void main(String[] args) {
		class Main {
			
	
				static class PowerOutage extends Exception {}
				static class Thunderstorm extends Exception {}
				public static void main(String[] args) throws Thunderstorm {
				try {
				new Main().listen();
				System.out.println("a");
				} catch(PowerOutage e) {
				e = new PowerOutage();
				System.out.println("b");
				} finally { System.out.println("c"); }
				}
				public void listen() throws PowerOutage, Thunderstorm{ }
				}
		 
            
	



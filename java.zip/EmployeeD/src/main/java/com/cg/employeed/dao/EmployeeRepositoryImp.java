package com.cg.employeed.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.cg.employeed.dto.Employee;
import com.cg.employeed.util.DbUtil;

public class EmployeeRepositoryImp implements EmployeeRepository {

	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		Connection con=DbUtil.getConnection();
		String query_insert = " INSERT INTO employeee VALUES(?,?,?)";
		PreparedStatement pstmt=null;
				
			try {
			    pstmt=con.prepareStatement(query_insert);
				pstmt.setInt(1, emp.getId());
				pstmt.setString(2, emp.getName());
				pstmt.setDouble(3, emp.getSalary());
			
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             finally {
            	 try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new EmployeeException("Connection not closed...");
				}
             }
			return null;
	}

	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		Connection con=DbUtil.getConnection();
		
		String query_show="SELECT emp_id,emp_name,emp_salary FROM employeee";
		List<Employee> myList=new ArrayList<Employee>();
		PreparedStatement pstmt=null;
		try {
			pstmt=con.prepareStatement(query_show);
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()) {
				Employee emp=new Employee();
				emp.setId(rs.getInt("emp_id"));
				emp.setName(rs.getString("emp_name"));
                emp.setSalary(rs.getDouble("emp_salary"));
                myList.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
       	 try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeException("Connection not closed...");
			}
        }
		return myList;
	}
}	
	
/*	List<Employee> empData;
	public EmployeeRepositoryImp() {
		 empData=new ArrayList<Employee>();
	}

	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		 empData.add(emp);
		  
		  return emp;
	}

	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		List<Employee> empSearch=new ArrayList();
		for (Employee employee : empData) {
			if(employee.getName().equals(name)) {
				empSearch.add(employee);
			}
			
		}
		return empSearch;
	}

	public List<Employee> findById(int id) {
		// TODO Auto-generated method stub
		List<Employee> empSearch1=new ArrayList();
		for (Employee employee : empData) 
			if(employee.getId()==id) {
				empSearch1.add(employee);
				return  empSearch1;
			}
			else {
				    throw new EmployeeException("id not found");
			      }return null;
	}

	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return empData;
	}*/



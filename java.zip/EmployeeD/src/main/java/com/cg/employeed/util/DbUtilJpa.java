/*package com.cg.employeed.util;

public class DbUtilJpa {

	EnitityManager em=null;
	public EntityManager getConnection() {}
}
*/
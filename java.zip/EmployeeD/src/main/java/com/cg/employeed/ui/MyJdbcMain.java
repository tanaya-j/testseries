/*package com.cg.employeed.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class MyJdbcMain {

	public static void main(String args[]) {
		String driver,url,uname,upass;
		
		
		//Connection using properties
				String driver1=null,url1=null,uname1=null,upass1=null;
				try {
					InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
					Properties prop= new Properties();
					prop.load(it);
					driver=prop.getProperty("jdbc.driver");
					url=prop.getProperty("jdbc.url");
					uname=prop.getProperty("jdbc.username");
					upass=prop.getProperty("jdbc.password");


				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "Capgemini123");
			//USER input
			Scanner scr = new Scanner(System.in);
			int emp_id = 0;
			String emp_name = null;
			double emp_salary = 0;
			PreparedStatement pstmt1=null;
			System.out.println("Enter Id");
			emp_id = scr.nextInt();
			System.out.println("Enter name");
			emp_name = scr.next();
			System.out.println("Enter Salary");
			emp_salary = scr.nextDouble();
			 pstmt1=conn.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
			pstmt1.setInt(1, emp_id);
			pstmt1.setString(2, emp_name);
			pstmt1.setDouble(3, emp_salary);
			int rs=pstmt1.executeUpdate();
			
			//inserting into db
			PreparedStatement pstmt=conn.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
			pstmt.setInt(1, 1001);
			pstmt.setString(2, "xyz");
			pstmt.setDouble(3, 10000.0);
			int rss=pstmt.executeUpdate();
			System.out.println(rss);
			
		
			
			//updating
			PreparedStatement pstmt2=conn.prepareStatement("UPDATE EMPLOYEE SET EMP_SALARY= ? where  EMP_ID= ? ");
			
		
			
			System.out.println("Enter id of which sal is to be updated:");
			int id=scr.nextInt();
			
			System.out.println("Enter the salary:");
			double sal=scr.nextDouble();
			
			pstmt2.setDouble(1, sal);
			pstmt2.setInt(2, id);
			pstmt2.executeUpdate();
			
			//deleting
			PreparedStatement pstmt3=conn.prepareStatement("DELETE FROM EMPLOYEE WHERE EMP_ID= ?");
			System.out.println("enter is to be deleted:");
			int id1=scr.nextInt();
			pstmt3.setInt(1, id1);
			pstmt3.executeUpdate();
			System.out.println("connection done..");
			
			
			
		 } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Driver not loaded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("not connected");
		}
     }
}
*/
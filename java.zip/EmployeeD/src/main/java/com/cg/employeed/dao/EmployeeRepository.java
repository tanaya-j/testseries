package com.cg.employeed.dao;

import java.util.List;

import com.cg.employeed.dto.Employee;



public interface EmployeeRepository {
	public Employee save(Employee emp);
	public List<Employee> findByName(String name);
	public List<Employee> findById(int id);
	public List<Employee> showAll();
}

package com.cg.employeed.service;

import java.util.List;

import com.cg.employeed.dto.Employee;



public interface EmployeeService {
	public void addEmployee(Employee emp);
	public List<Employee> searchByName(String name);
	public List<Employee> showAll();
	public Employee update(int id);
	public void sortAll();
}

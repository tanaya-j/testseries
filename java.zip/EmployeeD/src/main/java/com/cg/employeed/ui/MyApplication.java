package com.cg.employeed.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.employeed.dao.EmployeeException;
import com.cg.employeed.dto.Employee;
import com.cg.employeed.service.EmployeeService;
import com.cg.employeed.service.EmployeeServiceImp;


public class MyApplication {
	static EmployeeService service;
	   public MyApplication() {
		   
	   }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr=new Scanner(System.in);
		int choice=0;
		service=new EmployeeServiceImp();//in main because it will give null ptr exception
		do {
			 printDetails(); System.out.println("");
			 System.out.println("enter choice");
			
          choice=scr.nextInt();
          
          switch(choice) {
          case 1:
         	 System.out.println("enter employee id");
              int id=scr.nextInt();
              System.out.println("enter employee name");
              String name=scr.next();
              System.out.println("enter employee salary");
              double salary=scr.nextDouble();
          
              Employee emp=new Employee();
              emp.setId(id);
              emp.setName(name);
              emp.setSalary(salary);
              
              service.addEmployee(emp);
              
              break;
              
          case 2:
         	 List<Employee> myList=service.showAll();
         	 for(Employee empData : myList) {
         		 System.out.println("");
         		 System.out.println("Id is     "+empData.getId());
         		 System.out.println("Name is   "+empData.getName());
         		 System.out.println("Salary is "+empData.getSalary()); System.out.println("");
         		 
         	 }
         	 break;
         	 
          case 3:
         	 System.out.println("enter the name to be searched:");
         	 String sname=scr.next();
         	 List<Employee>empSearch=service.searchByName(sname);
         	 for(Employee empAll:empSearch)
         	 {
         		 System.out.println("Id is:" +empAll.getId());
         	 }
         	 break;
          
          case 4:
         	 System.out.println("Enter id to be searched:");
         	 int eid=scr.nextInt();
         	 try {
         	 service.update(eid);
         	 
         	 }catch(EmployeeException e) {
         		 System.out.println(e.getMessage());
         	 }// List<Employee>empSearch
          }
          
          
		}while(choice!=6);
	}
	
	
	public static void printDetails() {
		System.out.println("1.Add employee");
		System.out.println("2.Show employee");
		System.out.println("3.Search by name");
		System.out.println("4.Update employee");
	}
}

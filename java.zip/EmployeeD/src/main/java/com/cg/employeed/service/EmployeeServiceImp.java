package com.cg.employeed.service;

import java.util.List;

import com.cg.employeed.dao.EmployeeRepository;
import com.cg.employeed.dao.EmployeeRepositoryImp;
import com.cg.employeed.dto.Employee;

public class EmployeeServiceImp implements EmployeeService {
	
	EmployeeRepository dao;

	public EmployeeServiceImp() {
		dao= new EmployeeRepositoryImp();
	}

	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		//emp.setSalary(emp.getSalary()+(0.1*emp.getSalary()));
		dao.save(emp);
	}

	public List<Employee> searchByName(String name) {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}

	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	public Employee update(int id) {
		// TODO Auto-generated method stub
		List<Employee> empid=dao.findById(id);
		for(Employee empOne :empid)
		 empOne.setSalary(empOne.getSalary()+(0.1*empOne.getSalary()));
	return null;
	}

	public void sortAll() {
		// TODO Auto-generated method stub
		
	}

}

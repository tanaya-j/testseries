package com.cg.MavenDemoTwo.ui;

public class MyApplication {
  public static void main() {
	  System.out.println("Hello");
  }
}

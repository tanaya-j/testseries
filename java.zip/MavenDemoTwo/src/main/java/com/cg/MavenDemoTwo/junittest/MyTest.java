package com.cg.MavenDemoTwo.junittest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;

class MyTest {

	@Before
	void BeforeTest() {
		System.out.println("before test");
	}
	
	@Test
	void test() {
		System.out.println("My Test");
	}
	
	@After
	void AfterTest() {
		System.out.println("After Test");
	}

}

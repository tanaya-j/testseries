package com.cg.day3.ui;
import java.util.Scanner;

import com.cg.day3.dto.*;

public class MyMain {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c;
		User user=new User();
		Account account=new Account();
		Scanner scr=new Scanner(System.in);
		
		
		do
		{
		    
			System.out.println("Enter your choice:");
			System.out.println("1.Add 2.exit");
		    c=scr.nextInt();
		    
		    switch(c)
		    {
		    	case 1:  System.out.println("Enter the user id:");
		    	         int userId=scr.nextInt();
		    	         System.out.println("Enter the user name: ");
		    	         String userName=scr.next();
		    	         System.out.println("Enter the user address:");
		    	         String userAdd=scr.next();
		    	         System.out.println("Enter the account No:");
		    	         int acNo=scr.nextInt();
		    	         System.out.println("Enter the account balance:");
		    	         double bal=scr.nextDouble();
		    	        
		    	         System.out.println("User details are:");
		    	         user.setId(userId);
		    	         user.setName(userName);
		    	         user.setAddress(userAdd);
		    	         account.setAccountNo(acNo);
		    	         account.setBalance(bal);
		    	         user.setAccount(account);
		    	         System.out.println(user);
		    	         break;
		    	case 2:
		    	         System.exit(0);
		    	         break;
		    }
			
		}while(c != 0);
		
		}

	}
	
		
		/*User user1=new User();
		User user2=new User();
		
		
		Account account1=new Account();
		Account account2=new Account();
		
		
		user.setId(1);
		user.setName("Tanaya");
		user.setAddress("Pune");
		
		user1.setId(2);
		user1.setName("Pooja");
		user1.setAddress("Pune");
		
		user2.setId(3);
		user2.setName("Aishwarya");
		user2.setAddress("Pune");
		
		account.setAccountNo(101);
		account.setBalance(10000);
		
		account1.setAccountNo(102);
		account1.setBalance(20000);
		
		account2.setAccountNo(103);
		account2.setBalance(30000);
		
		user.setAccount(account);
		user1.setAccount(account1);
		user2.setAccount(account2);
		
		System.out.println("USER 1 ");
		System.out.println("Account user name is " +user.getName());
		System.out.println("Account user id  is  " +user.getAccount().getAccountNo());
		System.out.println("Account balance  is  " +user.getAccount().getBalance());
		
		System.out.println("\nUSER 2 ");
		System.out.println("Account user name is " +user1.getName());
		System.out.println("Account user id  is  " +user1.getAccount().getAccountNo());
		System.out.println("Account balance  is  " +user1.getAccount().getBalance());
		
		System.out.println("\nUSER 3 ");
		System.out.println("Account user name is " +user2.getName());
		System.out.println("Account user  id is  " +user2.getAccount().getAccountNo());
		System.out.println("Account balance  is  " +user2.getAccount().getBalance());*/
	
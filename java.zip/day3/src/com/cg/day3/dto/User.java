package com.cg.day3.dto;

public class User {
	
	private int id;
	private String name;
	private String address;
	private Account account;
	
	
	public User() {}
	
	
	
	public User(int id, String name, String address, Account account) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.account = account;
	}





	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}



	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + ", account=" + account + "]";
	}
	
	
	

}

package com.cg.day3.dto;

public class Account {
	
	private int AccountNo;
	private double Balance;
	
	
	public Account() {}


	public Account(int accountNo, double balance) {
		super();
		AccountNo = accountNo;
		Balance = balance;
	}


	public int getAccountNo() {
		return AccountNo;
	}


	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}


	public double getBalance() {
		return Balance;
	}


	public void setBalance(double balance) {
		Balance = balance;
	}


	@Override
	public String toString() {
		return "Account [AccountNo=" + AccountNo + ", Balance=" + Balance + "]";
	}
	
	

}

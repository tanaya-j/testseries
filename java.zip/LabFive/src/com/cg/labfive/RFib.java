package com.cg.labfive;

import java.util.Scanner;

public class RFib {

	public void getRfib(int n) {
	
		int first=1,second=1,next=0;
	    Scanner scr=new Scanner(System.in);
	    System.out.println("Enter the no of terms:");
	    int terms=scr.nextInt();
	
	for(int i=0;i<terms;i++) {
		System.out.print(" "+first);
		next=first+second;
		first=second;
		second=next;
		
	}
	 getRfib(n);
	}
	
	
	public static void main(String[] args) {
	int n=0;
		RFib f=new RFib();
	    f.getRfib(n);
	}

}

package com.cg.labfive;

public class MyMain {
	
	public static void main(String[] args) {
	
		try {
			new NameException().getAll(" "," ");
	    }catch(Name  e) {
		System.out.println(e.getMessage());
	}
	}

}
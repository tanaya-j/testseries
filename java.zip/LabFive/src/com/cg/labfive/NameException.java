package com.cg.labfive;

public class NameException {

	public void getAll(String firstName,String lastName) {
		
		if(firstName==" " || lastName==" " ) {
			throw new Name("Name is blank");
			}
		System.out.println(firstName+""+lastName);
	}
}

package com.cg.labfive;

import java.util.Scanner;

public class PrimeNos {

	static boolean isPrime(int n) 
	{ 
	   
	    if (n <= 1)  return false; 
	  
	    for (int i=2; i<n; i++) 
	        if (n % i == 0) 
	            return false; 
	  
	    return true; 
	} 
	
	
	static void printPrime(int n)
	{
		for(int i=2;i<=n;i++) {
			if(isPrime(i)) {
				System.out.println(""+i);
			}
			
		}
	}

    public static void main(String[] args) {
    	
    	Scanner scr=new Scanner(System.in);
    	System.out.println("Enter the value of n:");
    	int count=scr.nextInt();
    	
		
		printPrime(count);
    }
}

	/*public static void main (String[] args)
	   {		
	      Scanner scanner = new Scanner(System.in);
	      int i =0;
	      int num =0;
	     
	      String  primeNumbers = "";
	      System.out.println("Enter the value of n:");
	      int n = scanner.nextInt();
	      scanner.close();
	      for (i = 1; i <= n; i++)  	   
	      { 		 		  
	         int counter=0; 		  
	         for(num =i; num>=1; num--)
	         {
		    if(i%num==0)
		    {
			counter = counter + 1;
		    }
		 }
		 if (counter ==2)
		 {
		    
		    primeNumbers = primeNumbers + i + " ";
		 }	
	      }	
	      System.out.println("Prime numbers from 1 to " +n+ " are :");
	      System.out.println(primeNumbers);
	   }*/



package com.cg.labfive;

public class AgeException extends RuntimeException {
	
	public AgeException() {
		super();
	}
	
	public AgeException(String msg) {
		super(msg);
	}

}

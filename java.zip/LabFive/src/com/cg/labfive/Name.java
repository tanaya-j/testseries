package com.cg.labfive;

public class Name extends RuntimeException {
	public Name() {
		super();
	}
	
	public Name(String msg) {
		super(msg);
	}
}

package com.cg.labfive;



public class Age {

	public static void main(String[] args) {
		
		try {
				new MyAge().getAll(2);
		    }catch(AgeException  e) {
			System.out.println(e.getMessage());
		}
}
}
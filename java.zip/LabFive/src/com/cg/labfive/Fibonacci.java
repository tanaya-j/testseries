package com.cg.labfive;

import java.util.Scanner;

public class Fibonacci {
	public static void main(String args[ ]) {
		Scanner scr=new Scanner(System.in);
		int i,first=1,second=1,next=0,n;
		System.out.println("Enter the no of terms in series:");
		n=scr.nextInt();
		System.out.println("The series is");
		
		
		
		for(i=0;i<n;i++) {
			System.out.print(" "+first);
			next=first+second;
			first=second;
			second=next;
			
		}
		
		
	}

}

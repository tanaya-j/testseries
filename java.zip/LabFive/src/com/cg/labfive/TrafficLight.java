package com.cg.labfive;

import java.util.Scanner;

public class TrafficLight {

	public static void main(String[] args) {
		
		
		Scanner scr=new Scanner(System.in);
		int ch;
		do {
			System.out.println("Enter your choice:");
			System.out.println("1.Red 2.Yellow 3.Green");
		    ch=scr.nextInt();
		switch(ch) {
		
		case 1:System.out.println("stop");
		
		break;
		
		case 2:System.out.println("ready");
		
		break;
		
		case 3:System.out.println("Go");
		break;
		}	
			
			
		}while(ch!=0);
		
	}
	
}

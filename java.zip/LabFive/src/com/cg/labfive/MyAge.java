package com.cg.labfive;



public class MyAge {
public void getAll(int age)  {
		
		
		
		if(age<15) {
			throw new AgeException("Age should be greater than 15");
		}
		System.out.println(age);
		
	}
}


package com.cg.jpademoone.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpademoone.dto.Employee;
import com.cg.jpademoone.dto.Project;
import com.cg.jpademoone.service.EmployeeService;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeService services = null;
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoemployeemanagement");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Employee emp=new Employee();
		Project proj=new Project();
		int choice=0;
		Scanner scr= new Scanner(System.in);
		
		do {
			printDetails();
			System.out.println("Enter choice");
			choice=scr.nextInt();
			
			switch(choice) {
			
			case 1:
				System.out.println("Enter id:");
				int id=scr.nextInt();
				System.out.println("Enter name:");
				String name=scr.next();
				System.out.println("enter salary:");
				double salary=scr.nextDouble();
				
				System.out.println("Enter project id:");
				int pid=scr.nextInt();
				System.out.println("Enter project name:");
                String pname=scr.next();
                
                services.add(id, name, salary, proj);
               /* emp.setId(id);
                emp.setName(name);
			    emp.setSalary(salary);
			    emp.setProj(proj);
			    proj.setId(pid);
			    proj.setName(pname);
			    em.persist(emp);
			    em.persist(proj);*/
			    
			    break;
			    
			case 2:
				System.out.println("Enter employee id :");
				int eid=scr.nextInt();
				System.out.println("Enter the new employee name:");
			    String ename=scr.next();
			    System.out.println("Enter the new employee salary:");
			    Double sal=scr.nextDouble();
			    System.out.println("Enter the new project name:");
			    String projName=scr.next();
			    
			    Employee employee=em.find(Employee.class,eid);
			    if(employee!=null) {
			    	Project project=em.find(Project.class, employee.getProj().getId());
			    	project.setName(projName);
			    	employee.setName(ename);
			    	employee.setSalary(sal);
			    	employee.setProj(project);
			    	
			    	em.persist(employee);
			    	em.persist(project);
			    }
			   
			    break;
			    
			case 3:
				System.out.println("Enter the project id:");
				int projId=scr.nextInt();
				Project find=em.find(Project.class, proj.getName());
				Employee fin1=em.find(Employee.class,emp.getName());
				System.out.println("Project name is:" +proj.getName());
				System.out.println("Employee name is:"+emp.getName() );
				
				break;
				
			case 4:
				System.out.println("Enter the employee id which is to be deleted:");
				int empid=scr.nextInt();
				Employee e=em.find(Employee.class,empid);
				em.remove(e);
			    
				break;
			} em.getTransaction().commit();
	        em.close();
			
		}while(choice!=5);
		

	}
	
	
	public static void printDetails() {
		
		System.out.println("1.Add");
		System.out.println("2.Update");
		System.out.println("3.Search");
		System.out.println("4.Remove");
	}
 
}

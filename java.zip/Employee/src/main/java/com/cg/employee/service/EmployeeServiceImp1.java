package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImp1;
import com.cg.employee.dao.EmployeeException;
import com.cg.employee.dto.Employee;

public class EmployeeServiceImp1 implements EmployeeServices{
EmployeeDao dao;

public EmployeeServiceImp1() {
	dao= new EmployeeDaoImp1();
}


	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		emp.setSalary(emp.getSalary()+(0.1*emp.getSalary()));
		dao.save(emp);
		
	}


	public List<Employee> searchBy(String name) {
		// TODO Auto-generated method stub
		
		return dao.findByName(name);
	}
	


	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}


	public Employee update(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		List<Employee> empid=dao.findById(id);
		for(Employee empOne :empid)
		 empOne.setSalary(empOne.getSalary()+(0.1*empOne.getSalary()));
	return null;
	}


	public void sortAll() {
		// TODO Auto-generated method stub
		
	}
}

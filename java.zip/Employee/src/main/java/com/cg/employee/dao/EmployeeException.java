package com.cg.employee.dao;

public class EmployeeException extends RuntimeException{

	public EmployeeException() {
		super();
	}
	
	public EmployeeException(String msg) {
		super(msg);
	}
}

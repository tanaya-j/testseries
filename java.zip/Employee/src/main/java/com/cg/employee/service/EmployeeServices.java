package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dto.Employee;

public interface EmployeeServices {

	public void addEmployee(Employee emp);
	public List<Employee> searchBy(String name);
	public List<Employee> showAll();
	public Employee update(int id);
	public void sortAll();
	 
	
	
}

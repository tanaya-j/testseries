package com.cg.DaySix;

public interface IPaymentWalletService {

}

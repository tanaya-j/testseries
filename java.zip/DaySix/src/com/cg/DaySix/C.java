package com.cg.DaySix;

public class C implements A {

	@Override
	public void getAllData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		
	}
	/*default void getDefaultAll() {
		String name="Cap";
		System.out.println("Hi");
	}*/

	static void getStaticAll() {
		String name="Cap";
		System.out.println("Hi in C stattic");
	}
}

package com.cg.DaySix;

public class Transaction {

}

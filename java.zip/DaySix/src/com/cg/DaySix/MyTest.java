package com.cg.DaySix;

public class MyTest {

	public static void main(String[] args) 
	{
            A temp=new C();
            temp.getDefaultAll();
            A.getStaticAll();
		    C demo=new C();
		    demo.getStaticAll();

	}

	

}

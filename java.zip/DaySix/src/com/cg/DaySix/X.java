package com.cg.DaySix;

public class X {

}

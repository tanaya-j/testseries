package com.cg.DaySix;

public interface B extends A {

	public void setData();
}

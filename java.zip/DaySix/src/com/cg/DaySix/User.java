package com.cg.DaySix;

public class User {

}

package com.cg.DaySix;


    /*abstract*/ class E{
	
	static {
		System.out.println("In A");
	}
	static int x=10;
}
  
public class Day extends E   {

	public static void main(String args[]) throws ClassNotFoundException {
		System.out.println("in main");
		new E();
      // E.x=20;
		Class.forName("com.cg.DaySix.E");//loading class using class.forName
	}
}


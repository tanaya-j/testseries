package com.cg.DaySix;

public interface D extends A{

	public void setData();
	public void getMyName();
}


package com.cg.DaySix;

public interface A {

	public void getAllData();
	public void printAll();
	
	default void getDefaultAll() {
		String name="Cap";
		System.out.println("Hi");
	}
	
	static void getStaticAll() {
		String name="Cap";
		System.out.println("Hi in stattic");
	}
}

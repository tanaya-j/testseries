package com.cg.DaySeven.ui;

import java.io.IOException;

public class MyTest {

	public void getAll(int salary)  {
		
		
		/*int a=10;
		int b=0;*/
		
		if(salary<5000) {
			throw new EmployeeException("salary should be greater than 5000");
		}
		System.out.println(salary);
		//System.out.println("Result:"+a/b);
	}
}
		/*int c[]= {10,22,33};
		
		try {
			System.out.println(a/b);
			System.out.println(c[9]);
		}catch(ArithmeticException e) {
			System.out.println("check sec no");
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("check array ");
		}catch(Exception e) {
			System.out.println("In exception");
		}finally {
			System.out.println("Always");
		}
	System.out.println("HI");}*/


		/*int a[]= {10,2,3};
		
		try {
			System.out.println(a[5]);
	        }catch(NullPointerException e) {
			System.out.println("check array");
		}finally{
			System.out.println("always");
		}
	  System.out.println("in B");*/

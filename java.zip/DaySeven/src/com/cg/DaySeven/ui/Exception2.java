package com.cg.DaySeven.ui;
import java.io.*;


public class Exception2 {

	public static void main(String[] args) {
		
	try {
			new MyTest().getAll(2000);
	    }catch(EmployeeException  e) {
		System.out.println(e.getMessage());
	}
			/*try {
		    }catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("check your array");
		          }*/
	
	}
}

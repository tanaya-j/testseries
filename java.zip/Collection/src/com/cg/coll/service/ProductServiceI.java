package com.cg.coll.service;

import java.util.List;


import com.cg.collection.dto.Product;


public interface ProductServiceI {

public void addProduct(Product prod);


public void sort();
	
	public List<Product> searchByPrice(double min,double max);
	
	public List<Product> showall();
	
	public Product update(Product prod);
	
	public boolean remove(Product prod);
	
	public Product searchid(int id);

	
}

package com.cg.coll.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.coll.dao.EmployeeDao;
import com.cg.coll.dao.EmployeeDaoo;
import com.cg.coll.exe.EmployeeExe;
import com.cg.collection.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	
	
	EmployeeDaoo dao;
	
	public EmployeeServiceImpl()
	{
		dao=new EmployeeDao();
	}
	@Override
	public void addemp(Employee emp) {
		// TODO Auto-generated method stub
		
		
		
	//	emp.setSalary(emp.getSalary()+(emp.getSalary()*0.1));
		dao.save(emp);
	}

	@Override
	public List<Employee> searchName(String Name) {
		
		
		// TODO Auto-generated method stub
		return dao.findByName(Name);
	}

	@Override
	public List<Employee> showall() {
		// TODO Auto-generated method stub
		return dao.showall();
	}

	@Override
	public Employee update(Employee emp) throws EmployeeExe {
		// TODO Auto-generated method stub
		
		
		return null;
		

		
		}
			
		

	@Override
	public void sort() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Employee searchid(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}

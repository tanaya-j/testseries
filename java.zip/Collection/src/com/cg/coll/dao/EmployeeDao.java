package com.cg.coll.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.coll.exe.EmployeeExe;
import com.cg.collection.dto.Employee;

public class EmployeeDao implements EmployeeDaoo{

	List<Employee> empdata;
	public EmployeeDao()
	{
		empdata=new ArrayList<Employee>();
	}
	
	
	
	
	
	@Override
	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		
	
		empdata.add(emp);
		return emp;
	}

	@Override
	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		
		List<Employee> empsearch=new ArrayList<>();
		for (Employee empp : empdata) {
	        if (empp.getName().equals(name)) {
	           empsearch.add(empp);
	        }
	    }
		return empsearch;
	}

	@Override
	public Employee findById(int id) throws EmployeeExe {
		
		
	
		for (Employee employee : empdata) {
	     
			if (employee.getId()==id)
		{
	           return employee;
	    }else
	    {
	    	
	    	throw new EmployeeExe("id not found");
	    }
	        
	
		}
		return null;
		
	}

	@Override
	public List<Employee> showall() {
		// TODO Auto-generated method stub
		return empdata;
	}
	
	
	

}

package com.cg.coll.dao;

import java.util.List;

import com.cg.collection.dto.Product;



public interface ProductDaoI {

	
	public Product save(Product prod);
	public List<Product> findByPrice(double min,double max);
	
	public Product findById(int id);
	public List<Product> showall();
}

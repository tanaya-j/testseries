package com.cg.coll.dao;

import java.util.List;

import com.cg.coll.exe.EmployeeExe;
import com.cg.collection.dto.Employee;

public interface EmployeeDaoo {

	
	public Employee save(Employee emp);
	public List<Employee> findByName(String name);
	
	public Employee findById(int id) throws EmployeeExe;
	public List<Employee> showall();
	
}

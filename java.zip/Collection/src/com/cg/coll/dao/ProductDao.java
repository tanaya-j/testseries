package com.cg.coll.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.coll.exe.EmployeeExe;
import com.cg.coll.exe.ProductExce;
import com.cg.collection.dto.Employee;
import com.cg.collection.dto.Product;

public class ProductDao implements ProductDaoI{

	List<Product> proddata;
	public ProductDao()
	{
		proddata=new ArrayList<Product>();
	}
	
	
	
	
	
	@Override
	public Product save(Product prod) {
		// TODO Auto-generated method stub
	proddata.add(prod);
	return prod;
	
	}

	@Override
	public List<Product> findByPrice(double min,double max) {
		// TODO Auto-generated method stub
		List<Product> prodsearch=new ArrayList<>();
		for (Product prodc : proddata) {
	       if(prodc.getPrice() <= max && prodc.getPrice() >= min) {
	           prodsearch.add(prodc);
	        }
	    }
		return prodsearch;
	}

	@Override
	public Product findById(int id) throws ProductExce {
		for (Product prod : proddata) {
		     
			if (prod.getId()==id)
		{
	           return prod;
	    }else
	    {
	    	System.out.println("Id not Found");
	    }
	        
	
		}
		return null;
		
	}
	

	@Override
	public List<Product> showall() {
		// TODO Auto-generated method stub
		return proddata;
	}

}

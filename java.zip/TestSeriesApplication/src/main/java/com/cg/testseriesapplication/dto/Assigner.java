package com.cg.testseriesapplication.dto;

import java.util.Date;

public class Assigner {

    private	Date date;
	private MyTest test;
	private Candidate candidate;
	
	public Assigner() {}

	public Assigner(Date date, MyTest test, Candidate candidate) {
		super();
		this.date = date;
		this.test = test;
		this.candidate = candidate;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public MyTest getTest() {
		return test;
	}

	public void setTest(MyTest test) {
		this.test = test;
	}

	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}

	@Override
	public String toString() {
		return "TestAssigner [date=" + date + ", test=" + test + ", candidate=" + candidate + "]";
	}
	
	
}

package com.cg.testseriesapplication.service;

import java.util.List;

import com.cg.project.dto.Test;

public interface TestService {

	
	public MyTest createMyTest(MyTest test);
	public List<MyTest> searchTestByName(String testName);
}

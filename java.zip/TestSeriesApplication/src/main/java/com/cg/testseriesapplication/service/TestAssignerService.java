package com.cg.testseriesapplication.service;

import com.cg.testseriesapplication.dto.Candidate;
import com.cg.testseriesapplication.dto.MyTest;
import com.cg.testseriesapplication.dto.Assigner;

public interface TestAssignerService {

	
	public Assigner assignTestToCandidate(int id,String testName);
	
}

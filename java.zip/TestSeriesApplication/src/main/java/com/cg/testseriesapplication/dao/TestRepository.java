package com.cg.testseriesapplication.dao;

import java.util.List;

import com.cg.project.dto.Test;

public interface TestRepository {

	public MyTest saveTest(MyTest test);
	public List<MyTest> findByName(String testName);
}

package com.cg.testseriesapplication.service;

import java.util.List;

import com.cg.project.dto.Test;

public class TestServiceImplements implements TestService {

	public MyTest createMyTest(MyTest test) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<MyTest> searchTestByName(String testName) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.cg.testseriesapplication.dto;

import java.math.BigInteger;

public class Candidate {

	   private int Id;
	   private String name;
       private BigInteger contact;
       
       public Candidate() {}

	public Candidate(int id, String name, BigInteger contact) {
		super();
		Id = id;
		this.name = name;
		this.contact = contact;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getContact() {
		return contact;
	}

	public void setContact(BigInteger contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "Candidate [Id=" + Id + ", name=" + name + ", contact=" + contact + "]";
	
	}
       
       

}

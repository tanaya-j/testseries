package com.cg.testseriesapplication.dto;

import java.math.BigInteger;
import java.util.List;

public class MyTest {

	private String testName;
	private BigInteger totalquestions;
	private BigInteger totalMarks;
	private List<Question> questions;
	
	public MyTest() {
		
	}

	public MyTest(String testName, BigInteger totalquestions, BigInteger totalMarks, List<Question> questions) {
		super();
		this.testName = testName;
		this.totalquestions = totalquestions;
		this.totalMarks = totalMarks;
		this.questions = questions;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public BigInteger getTotalquestions() {
		return totalquestions;
	}

	public void setTotalquestions(BigInteger totalquestions) {
		this.totalquestions = totalquestions;
	}

	public BigInteger getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(BigInteger totalMarks) {
		this.totalMarks = totalMarks;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Test [testName=" + testName + ", totalquestions=" + totalquestions + ", totalMarks=" + totalMarks
				+ ", questions=" + questions + "]";
	}
}

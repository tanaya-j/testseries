package com.cg.testseriesapplication.dao;

import com.cg.testseriesapplication.dto.Candidate;
import com.cg.testseriesapplication.dto.MyTest;
import com.cg.testseriesapplication.dto.Assigner;

public interface TestAssignerRepository {

	public Assigner save(int id,String testName); 
}

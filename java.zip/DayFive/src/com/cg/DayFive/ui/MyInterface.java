package com.cg.DayFive.ui;

public class MyInterface {

}

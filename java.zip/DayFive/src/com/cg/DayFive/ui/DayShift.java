package com.cg.DayFive.ui;

public class DayShift extends Time {

	@Override
	public void login() {
		// TODO Auto-generated method stub
		System.out.println("in login");
	}

	@Override
	public double logout() {
		// TODO Auto-generated method stub
		return 12.4;
	}

}

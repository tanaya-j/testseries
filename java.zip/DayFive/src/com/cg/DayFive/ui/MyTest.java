package com.cg.DayFive.ui;

public class MyTest {

	public static void main(String[] args) {
		
		A temp=(A)new B();
		((A)temp).getAll();
		/*B temp=new A();
        temp.getAll();*/
        System.out.println(temp.a);//will give 10 as output as ref to B is given
	}
	
}

class B{

   static int a=10;
	public void getAll()
{
	System.out.println("in B");
	
}}

class A extends B{
	int a=20;
	public void getAll()
	{
		
		System.out.println("in A");
		
	}
	}

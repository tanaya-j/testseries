package com.cg.DayFive.ui;

public class MyTe {

	public static void main(String[] args) {
		Time temp=new DayShift();
        temp.login();
        temp.logout();
        temp.getCompany();
	System.out.println(temp.time);
		
	}
	
}

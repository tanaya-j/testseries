package com.cg.DayFive.ui;

public abstract class Time {
	
	double time=9.5;

	public abstract void login();
	
	public abstract double logout();
	
	public String getCompany() {
		return "CAPGEMINI";
	}
}

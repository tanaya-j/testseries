package com.cg.DayFive.ui;

public class DayShift implements Time {

	@Override
	public void login() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double logout() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getCompany() {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.cg.DayFive.ui;

public interface Time {
	
public void login();
	
double time=9.5;
	public  double logout();
	public String getCompany(); 
	
}

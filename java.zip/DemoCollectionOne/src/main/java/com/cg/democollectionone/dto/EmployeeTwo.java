package com.cg.democollectionone.dto;

import java.util.Comparator;

public class EmployeeTwo<T,K> {

	private T id;
	private String name;
	private K salary;
	
	
	
	public EmployeeTwo() {
		super();
		// TODO Auto-generated constructor stub
	}



	

	public EmployeeTwo(T id, String name, K salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}





	public T getId() {
		return id;
	}





	public void setId(T id) {
		this.id = id;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public K getSalary() {
		return salary;
	}





	public void setSalary(K salary) {
		this.salary = salary;
	}





	@Override
	public String toString() {
		return "EmployeeTwo [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}





	public int compareTo(EmployeeTwo o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}

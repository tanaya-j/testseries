package com.cg.democollectionone.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.cg.democollectionone.dto.Employee;
import com.cg.democollectionone.dto.EmployeeCom;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee empone = new Employee(1006,"ff",9999);
Employee emptwo = new Employee(1004,"gf",9999);
Employee empthree = new Employee(1002,"nf",9999);
Employee empfour = new Employee(1005,"jj",9999);
List<Employee> mylist = new ArrayList<Employee>();
mylist.add(empone);
mylist.add(emptwo);
mylist.add(empthree);
mylist.add(empfour);



//Collections.sort(mylist, new EmployeeCom());
System.out.println(mylist);



	}

}

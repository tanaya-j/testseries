package com.cg.product.dto;

import java.util.Scanner;

public class Product {

	private int productId;
	private String productName;
	private double productCost;
	private String productDesc;
	
	
	public Product() {}
	
	public Product(int productId, String productName, double productCost, String productDesc) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCost = productCost;
		this.productDesc = productDesc;
	}

  public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductCost() {
		return productCost;
	}

	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	/* public void create() {
	   Scanner scr=new Scanner(System.in);
	   System.out.println("Enter the product id");
	   productId=scr.nextInt();
	   System.out.println("Enter the product name");
	   productName=scr.next();
	   System.out.println("Enter the product cost");
	   productCost=scr.nextDouble();
	   System.out.println("Enter the product desc");
	   productDesc=scr.next();
     }
   
   public void display()
   {
	   System.out.println("The product details are: ");
	   System.out.println("Product Id is:   "+productId);
	   System.out.println("Product name is: "+productName);
	   System.out.println("Product cost is: "+productCost);
	   System.out.println("Product desc is: "+productDesc);
   }
   
  */
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productCost=" + productCost
				+ ", productDesc=" + productDesc + "]";
	}

	
}

/*package com.cg.product.ui;
import java.util.Scanner;
import com.cg.product.dto.Product;

public class MyTest {
	
	//String[] choices=new choices[10];
     //static String choices[]= {"Add","Show","Exit"};
	// static int i;
	//int n = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c;
		Scanner scr=new Scanner(System.in);
	    System.out.println("Enter the no products  ");
	    int n= scr.nextInt();
	    Product prod[] =new Product[n];
		
		
	    
	    prod=new Product[n];
	   
	    
	    for(int i=0;i<n;i++)
	 	prod[i]=new Product();
	   
		do 
              {
			  System.out.println("Enter your choice");
			  System.out.println("1.Add 2.Display 3.exit");
			  c=scr.nextInt();
			  
			 
			switch(c)
			    {
			    	case 1:  for(int i = 0;i<n;i++) {
			    		          System.out.println("Enter the product details:");
			    		          prod[i].create();
			    	          }
			    	      break;
			    	    
			    	case 2:for(int i = 0;i<n;i++) {
	    		         // System.out.println(" the product details:");
	    		          prod[i].display();
	    	          }
	    	         
			    	case 3:
			    		
			    		System.out.println("exit");
			    	    break;     
			    }	        
			    	        
}while(c !=0);
		
}

}
*/
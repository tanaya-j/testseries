package com.cg.product.ui;

import java.util.Scanner;

import com.cg.product.dto.Product;
import com.cg.product.service.ProductService;
import com.cg.product.service.iProductService;

public class MyMain {

	public static void main(String[] args) {
		printDetails();
		//Product pro=new Product();
	Scanner scr=new Scanner(System.in);
	iProductService service=new ProductService();
	int choice=0;
	do {  
		Product pro=new Product();
	     System.out.println("Enter choice");
	     choice=scr.nextInt();
	     switch(choice) {
	     case 1:  System.out.println("Enter the product id");
		  int productId=scr.nextInt();
		   System.out.println("Enter the product name");
		   String productName=scr.next();
		   System.out.println("Enter the product cost");
		   double productCost=scr.nextDouble();
		   System.out.println("Enter the product desc");
		   String productDesc=scr.next();
		   
		   pro.setProductId(productId);
		   pro.setProductName(productName);
		   pro.setProductCost(productCost);
		   pro.setProductDesc(productDesc);
		   
		   service.addProduct(pro);
	     break;
	     
	     case 2: System.out.println("The details are:");
	      Product[] allData=service.showAllProduct();
	      for(Product product : allData) {
	    	  System.out.println("Product id is:"+product.getProductId());
	    	  System.out.println("Product name is:"+product.getProductName());
	    	  System.out.println("Product cost is:"+product.getProductCost());
	    	  System.out.println("Product desc is:"+product.getProductDesc());
	      }
	     //System.out.println(service.showAllProduct());
	     break;
	     
	     case 3:System.out.println("exit");
	     }
	
       }while(choice!=0);

}
	
	public static void printDetails() {
	System.out.println("---------------------");
	System.out.println("1.Add Product");
	System.out.println("2.Show Products");
	System.out.println("3.Exit");
}
}
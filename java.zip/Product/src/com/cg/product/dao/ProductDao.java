package com.cg.product.dao;

import com.cg.product.dto.Product;

public class ProductDao implements IProductDao{

	Product prod[];
	int i=0;
	public ProductDao() {
		prod=new  Product[2];
	}
	
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		
			 prod[i]=new Product();
			 prod[i].setProductId(pro.getProductId());
			 prod[i].setProductName(pro.getProductName());
			 prod[i].setProductCost(pro.getProductCost());
			 prod[i].setProductDesc(pro.getProductDesc());
		i++;
		return pro;
	}

	@Override
	public Product[] showAll() {
		// TODO Auto-generated method stub
		return prod;
	}

}

package com.cg.product.dao;

import com.cg.product.dto.Product;

public interface IProductDao {

	public Product addProduct(Product pro);
	public Product[] showAll();
	
}

package com.cg.product.service;

import com.cg.product.dao.IProductDao;
import com.cg.product.dao.ProductDao;
import com.cg.product.dto.Product;

public class ProductService implements iProductService{
 
	IProductDao dao;
	
	public ProductService() {
		dao=new ProductDao();
	}
	  
	
	
	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		
		return dao.addProduct(prod);
	}

	@Override
	public Product[] showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	
}

package com.cg.product.service;

import com.cg.product.dto.Product;

public interface iProductService {

	public Product addProduct(Product prod);
    public Product[] showAllProduct();
    
  
}

package com.cg.product.junittest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.product.dto.Product;
import com.cg.product.service.ProductService;
import com.cg.product.service.iProductService;

class ProductTest {
  iProductService service;
  Product prod;
	 
	@BeforeEach
	public void beforeTest() {
		service=new ProductService();
		prod=new Product();
		prod.setProductId(1001);
		prod.setProductName("Book");
		prod.setProductCost(129029);
		prod.setProductDesc("thriller novel");
	}
	
	@Test
	public void MyTest() {
		assertNotNull(service.addProduct(prod));
	} 
	
	@Test
	public void MyTestTwo() {
		assertNotNull(service.showAllProduct());
	} 
	@AfterEach
	public void afterEach() {
		service=null;
	}
}

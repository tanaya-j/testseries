package com.cg.dayfour.ui;
import java.math.BigDecimal;
import com.cg.dayfour.dto.Employee;

public class MyTest {

	double Salary=1000;
	/*static void getAllData() {
		
		System.out.println("Static");
	}
	
	void getData()
	{
		System.out.println("Non Static");
		getAllData();
	}*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("In main");
		//A.getAll(); 
	}
	
	
		
	static{
			System.out.println("in static block");
		     }
	}
		//MyTest emp=new MyTest();
		
		
		//getAllData();
		
		//emp.getData();
		//
	

	/*Class A {
		
		static {
			System.out.println("in static block");
		}
		
		public A() {
			System.out.println("in A");
		}
		
		public static void main() {
			
		}
	}*/
		
		//getData();
	
		/*Employee emp=new Employee(10,"tanaya",new BigDecimal(10000),0.1);
		
		System.out.println("Employee ID is:     "+emp.getEmpID());
		System.out.println("Employee Name is:   "+emp.getFullName());
		System.out.println("Employee Salary is: "+emp.takeHomeSalary());
		Employee.pf=1200;
		System.out.println("Pf is: " +Employee.pf);
		
        Employee empOne=new Employee(11,"ph",new BigDecimal(10000),0.1);
		
		System.out.println("Employee ID is:     "+empOne.getEmpID());
		System.out.println("Employee Name is:   "+empOne.getFullName());
		System.out.println("Employee Salary is: "+empOne.takeHomeSalary());*/
		
		
		
	
	/*private static void getAllData() {
		// TODO Auto-generated method stub
		
	}
	private static void getData() {
		// TODO Auto-generated method stub
       */		
	
package com.cg.dayfour.ui;

public class MyTst {
	
	public static void main(String args[]) {
    B temp=new  B();
    System.out.println(temp.a);
    temp.getAll();
	}
	
}


class A 
{
	int a=10;
	
	public A() {
		System.out.println("A");
	}
	
	public void getAll() {
		System.out.println("in method of A");
	}
}

class B extends A {
	public B() {
		
		System.out.println("B");
	}
}
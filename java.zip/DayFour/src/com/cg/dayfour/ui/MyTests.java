/*package com.cg.dayfour.ui;

public class MyTests {

	public static void main(String args[]) {
		A.B temp=new A.B();//static class
		temp.getAll();
		
		A demo=new A();
		demo.getA();
	}
	
}

class A
{
  private static int a=10;
   static class B{
    	static  int b=20;
    	  public void getAll() {
    		  System.out.println("B");
    	  }
    	  
    }
    
    public void getA() {
    	System.out.println("in A");
    }
}*/
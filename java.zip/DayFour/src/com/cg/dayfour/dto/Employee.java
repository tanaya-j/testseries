package com.cg.dayfour.dto;

import java.math.BigDecimal;

public class Employee {
	
	private int empID;
	private String empName;
	public static double pf;
	private BigDecimal empSalary;
	private double increment;
	
	public Employee() {}
	
	public Employee(int empID, String empName,  BigDecimal empSalary, double increment) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.pf = pf;
		this.empSalary = empSalary;
		this.increment = increment;
	}

	public int getEmpID() {
		return empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public BigDecimal getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(BigDecimal empSalary) {
		this.empSalary = empSalary;
	}

	public double getIncrement() {
		return increment;
	}

	public void setIncrement(double increment) {
		this.increment = increment;
	}

	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + ", pf=" + pf + ", empSalary=" + empSalary
				+ ", increment=" + increment + "]";
    }
	
	public BigDecimal takeHomeSalary() {
		BigDecimal inc=BigDecimal.valueOf(this.increment);
		BigDecimal pfa=BigDecimal.valueOf(this.pf);
		BigDecimal takeHomeSalary=this.empSalary.add(this.empSalary.multiply(inc)).subtract(pfa);
		return takeHomeSalary;
		
	}
	
	public String getFullName() {
		return this.empName  + " capgemini";
	}

}

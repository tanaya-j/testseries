package com.cg.testseriesjpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.testseriesjpa.dto.Question;
import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.TestNotFoundException;
import com.cg.testseriesjpa.exception.dataNotFound;
import com.cg.testseriesjpa.util.DbUtil;

/*This class implements the test repository interface */
public class TestRepositoryImplements implements TestRepository {
 EntityManager em;
	public TestRepositoryImplements() {
         em=DbUtil.em;
	}
	//saves the created test in the database
	public Test saveTest(Test test) {
		em.getTransaction().begin();
	    em.persist(test);
	    em.getTransaction().commit();
	    return null;
	}
	
	//finds test by name
	public Test findByName(String testName) throws dataNotFound {
		 Test test =new Test();
		try {
		
			  
			   Query query=em.createQuery("FROM Test t where t.name = :testName ");
			   query.setParameter("testName",testName );
			   test=(Test) query.getSingleResult();
		       
		}
		catch(Exception e)
		{
			throw new dataNotFound("test not found..!!!");
		}
		return test;
	}

	//finds test by Id
	public Test findById(int id) {
	  return em.find(Test.class,id);
		}
}
		


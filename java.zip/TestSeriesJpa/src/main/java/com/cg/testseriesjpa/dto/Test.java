package com.cg.testseriesjpa.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/*
 * This is bean class for Test it includes id ,name,total questions,total marks,list of questions
 * Constructor,getter setter ,toString is defined
 * last Modified 06/05/2019
 * Author:Tanaya Jadhav
 * */

@Entity
@Table(name="Test")
public class Test {
	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="test_id")
	private int id;//primary key
	@Column(name="test_name")
	private String name;//name of test
	@Column(name="total_question")
	private BigInteger totalquestions;//total questions
	@Column(name="test_marks")
	private BigInteger totalMarks;//total marks
	@OneToMany(cascade= {CascadeType.PERSIST,CascadeType.ALL},targetEntity=Question.class)
	@JoinColumn(name="test_Id")//joins the column
	private List<Question> questions=new ArrayList<Question>();
	
	public Test() {}

	//constructor with fields
	public Test( String name, BigInteger totalquestions, BigInteger totalMarks, List<Question> questions) {
		super();
	    this.name = name;
		this.totalquestions = totalquestions;
		this.totalMarks = totalMarks;
		this.questions = questions;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getTotalquestions() {
		return totalquestions;
	}

	public void setTotalquestions(BigInteger totalquestions) {
		this.totalquestions = totalquestions;
	}

	public BigInteger getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(BigInteger totalMarks) {
		this.totalMarks = totalMarks;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Test [id=" + id + ", name=" + name + ", totalquestions=" + totalquestions + ", totalMarks=" + totalMarks
				+ ", questions=" + questions + "]";
	}
}

package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dto.Candidate;

/*This a candidate service interface which includes add candidates and serachBy  id method*/

public interface CandidateService {
  public Candidate addCandidate(Candidate candidate);//adds the candidate
  public Candidate searchById(int id);//search the candidate by its id
}

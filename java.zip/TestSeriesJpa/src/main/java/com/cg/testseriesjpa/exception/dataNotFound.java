package com.cg.testseriesjpa.exception;

public class dataNotFound extends Exception {
	public dataNotFound()
	{
		
	}
	public dataNotFound(String msg)
	{
		super(msg);
	}

}

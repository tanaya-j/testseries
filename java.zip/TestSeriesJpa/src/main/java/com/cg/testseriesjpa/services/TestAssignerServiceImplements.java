package com.cg.testseriesjpa.services;


import com.cg.testseriesjpa.dao.TestAssignerRepository;
import com.cg.testseriesjpa.dao.TestAssignerRepositoryImp;
import com.cg.testseriesjpa.dto.Assigner;

/*
 * This class implements the test assigner service interface*/
public class TestAssignerServiceImplements implements TestAssignerService {

TestAssignerRepository assignerDao;
	
   static int assignerId=1;
	public TestAssignerServiceImplements() {
		
		assignerDao=new TestAssignerRepositoryImp();
	}
	
	//assigns test to candidate
	public Assigner assignTestToCandidate(Assigner assigner) {
		// TODO Auto-generated method stub
		assigner.setId(assignerId);
		assignerId++;
		assignerDao.save(assigner);
		return assigner;
	}

	

}

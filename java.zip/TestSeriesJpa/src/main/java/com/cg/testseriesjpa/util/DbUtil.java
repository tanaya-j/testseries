package com.cg.testseriesjpa.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbUtil {

public static EntityManager em=Persistence.createEntityManagerFactory("testseriesapp").createEntityManager();
//=Persistence.createEntityManagerFactory("testseriesapp").createEntityManager();

/*public static EntityManager getConnection() {
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("testseriesapp");
	em = emf.createEntityManager();
	em.getTransaction().begin();
	return em;
  }*/
}

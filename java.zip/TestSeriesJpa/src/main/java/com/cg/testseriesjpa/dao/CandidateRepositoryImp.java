package com.cg.testseriesjpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import com.cg.testseriesjpa.dto.Candidate;
import com.cg.testseriesjpa.dto.Question;
import com.cg.testseriesjpa.exception.CandidateNotFoundException;
import com.cg.testseriesjpa.exception.TestNotFoundException;
import com.cg.testseriesjpa.util.DbUtil;

/*
 * This is a implementation of candidate repository which implements */
public class CandidateRepositoryImp implements CandidateRepository {

	static EntityManager em;


public CandidateRepositoryImp(){
	em=DbUtil.em;
}
	
	//saves the candidate
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
	
	    em.getTransaction().begin();
		em.persist(candidate);
		em.getTransaction().commit();
		return null;
		
			
	}

	//finds the candidate by its Id
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
          return em.find(Candidate.class, id);
		}
}
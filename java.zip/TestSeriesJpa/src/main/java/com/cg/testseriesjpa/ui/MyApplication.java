package com.cg.testseriesjpa.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.testseriesjpa.dto.Assigner;
import com.cg.testseriesjpa.dto.Candidate;
import com.cg.testseriesjpa.dto.Question;
import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.CandidateNotFoundException;
import com.cg.testseriesjpa.exception.TestNotFoundException;
import com.cg.testseriesjpa.exception.dataNotFound;
import com.cg.testseriesjpa.services.CandidateService;
import com.cg.testseriesjpa.services.CandidateServiceImplements;
import com.cg.testseriesjpa.services.TestAssignerService;
import com.cg.testseriesjpa.services.TestAssignerServiceImplements;
import com.cg.testseriesjpa.services.TestService;
import com.cg.testseriesjpa.services.TestServiceImplements;
/*This is a main class */
public class MyApplication {
	
	        static TestService services;
		    static TestAssignerService assignerServices;
		    static CandidateService candidateServices; 
		    public static void main(String[] args) throws IOException {
			
			services=new TestServiceImplements();//testservice object
			assignerServices=new TestAssignerServiceImplements();//testassignerservice object
			candidateServices=new CandidateServiceImplements();//candidate service object
			Test test=null;
			List<Question> myQuestions;//list of questions
			Assigner assigner=null;
			Question question;
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//to read lines
			Scanner scr=new Scanner(System.in);
			int choice=0;//scans the choices
			int id;
//			Random random=new Random();
			
		do {
				printDetails();
				System.out.println("Enter choice");
				choice=scr.nextInt();
				
				switch(choice) {
			
				//Creates test
				case 1:
					  /* int tid=random.nextInt();
					   tid=tid+1;*/
					   System.out.println("Enter test name:");
				       String testName=br.readLine();
				       System.out.println("Enter the total no of questions");
				       BigInteger totalquestions=scr.nextBigInteger();
				       System.out.println("Enter total marks");
				       BigInteger totalMarks=scr.nextBigInteger();
				       myQuestions=new ArrayList<Question>();
				       do {
				    	  /* int qid=random.nextInt();
						   qid=qid+1;*/
				    	   System.out.println("Enter the question:");
				    	   String content=br.readLine();
				    	   System.out.println("Enter the option A");
				    	   String optionA=br.readLine();
				    	   System.out.println("Enter the option B");
				    	   String optionB=br.readLine();
				    	   System.out.println("Enter the option C");
				    	   String optionC=br.readLine();
				    	   System.out.println("Enter the correct option:");
				    	   String correctOption=br.readLine();
				    	  
				    	   question=new Question(content,optionA,optionB,optionC,correctOption);
				    	   myQuestions.add(question);
				    	   System.out.println("press 1 to continue adding questions/press 2 to exit");
				    	   choice=scr.nextInt();
				    	 }while(choice!=2);
				      /* try {
					    	  services.searchTestById(tid);
					       }catch(TestNotFoundException e) {
					    	   System.out.println(e.getMessage());
					       }*/
				           test=new Test(testName, totalquestions,totalMarks , myQuestions);
				           services.createMyTest(test); 
				  break;
				       
				 //Search test      
				case 2:System.out.println("Enter the test to be searched:");
				       String tname=br.readLine();
				       try {
				       Test testdetails= services.searchTestByName(tname);
				       System.out.println(testdetails);
				       }catch(TestNotFoundException e) {
				    	   System.out.println(e.getMessage());
				       } catch (dataNotFound e) {
						// TODO Auto-generated catch block
				    	   System.out.println(e.getMessage());
					}
				  break;
				  
				//Add candidates
				case 3:/*System.out.println("Enter the candidate id:");
					   int candId=scr.nextInt();*/
					   /*int cid=random.nextInt();
					   cid=cid+1;*/
					   System.out.println("Enter the candidate name:");
					   String name=scr.next();
					   Candidate candidate=new Candidate(name);
					   candidateServices.addCandidate(candidate);
					   
				  break;
				
				  //Assigns the test and saves details in database
				case 4:/*int aid=random.nextInt();
				       aid=aid+1;*/
			           System.out.println("Enter the id of the candidate to whom test is to be assigned");
				       int ccid=scr.nextInt();
				       try {
				    	   candidate=candidateServices.searchById(ccid);
				    	   System.out.println(candidate);
				      }catch(CandidateNotFoundException e) {
				    	 System.out.println(e.getMessage()); break;}
					  
				       System.out.println("Enter the id of test:");
				      int tidd=scr.nextInt();
				       try { 
					    	 test= services.searchTestById(tidd);
					    	 System.out.println(test);
					     }catch(TestNotFoundException e) {
					    	 System.out.println(e.getMessage());
					    	 break;
					    	 
					     }
				       //System.out.println("Enter date:");
				       long milli=System.currentTimeMillis();
				       Date date=new Date(milli);
				       System.out.println(date);
				 
				      assigner=new Assigner(date,test,candidate);
				      
				      try { assignerServices.assignTestToCandidate(assigner);
				      System.out.println("test is assigned to candidate id  " + ccid);
				      }catch(CandidateNotFoundException e) {
				    	  System.out.println(e.getMessage());
				    	  
				      }
				   break;
				   
				case 5:
					System.out.println("exited..!!!");System.exit(1);
				}
			}while(choice!=6);
		} 
		
		    public static void printDetails() {
			System.out.println("------------------------------------");
			System.out.println("1. Create Test");
			System.out.println("2. Find   Test");
			System.out.println("3. Add    Candidates");
			System.out.println("4. Assign Test");
			System.out.println("5.Exit");
			System.out.println("------------------------------------");
		   }
	}



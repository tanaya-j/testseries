package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.dataNotFound;

/*
 * This a test interface it includes methods for creating test ,searching test by name and Id*/
public interface TestService {
	public Test createMyTest(Test test);
	public Test searchTestByName(String testName) throws dataNotFound;
	public Test searchTestById(int id);
}

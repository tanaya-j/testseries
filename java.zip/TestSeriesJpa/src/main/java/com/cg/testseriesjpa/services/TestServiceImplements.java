package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dao.TestRepository;
import com.cg.testseriesjpa.dao.TestRepositoryImplements;
import com.cg.testseriesjpa.dto.Question;
import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.TestNotFoundException;
import com.cg.testseriesjpa.exception.dataNotFound;

/*This class is implementation of test service interface which implements create test ,search test 
 * by name and id methods..!*/
     public class TestServiceImplements implements TestService{
      TestRepository dao;
	  static int testId=1;
	  static int questionId=1;
	  public TestServiceImplements() {
		dao= new TestRepositoryImplements();
	}
	
	//creates the test
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		test.setId(testId);
       // Question question=null;
		for(Question que : test.getQuestions()) {
		    que.setId(questionId);
			questionId++;
		}
		testId++;
		return dao.saveTest(test);
	}

	//search test by name
    public Test searchTestByName(String testName) throws dataNotFound {
		Test t= dao.findByName(testName);
    	if(t==null) {
    		throw new TestNotFoundException("Test not created..!!!!");
    	  }
		return t;
    	
	}

	//search test by Id
	public Test searchTestById(int id) {
		// TODO Auto-generated method stub
		if(dao.findById(id)==null) {
			throw new TestNotFoundException("Test not created..!!!!");
		}
		return dao.findById(id);
	}
}

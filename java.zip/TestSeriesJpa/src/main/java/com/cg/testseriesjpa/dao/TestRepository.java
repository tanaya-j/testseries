package com.cg.testseriesjpa.dao;

import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.dataNotFound;

public interface TestRepository {
	public Test saveTest(Test test);
	public Test findByName(String testName) throws dataNotFound;
	public Test findById(int id);
}

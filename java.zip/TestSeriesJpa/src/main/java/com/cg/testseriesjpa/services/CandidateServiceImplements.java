package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dao.CandidateRepositoryImp;
import com.cg.testseriesjpa.dto.Candidate;
import com.cg.testseriesjpa.exception.CandidateNotFoundException;

/*
 * This class is a implementation of candidate service interface.
 * It includes add candidate and search candidate by id methods.
 * */
public class CandidateServiceImplements implements CandidateService {
	static int candidateId=100;
	CandidateRepositoryImp dao;
	
	public CandidateServiceImplements() {
		dao=new CandidateRepositoryImp();}
	
	//add the candidate
	public Candidate addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		candidate.setId(candidateId);
		candidateId++;
		dao.saveCandidate(candidate);
	    return null;
	}

	//search the candidate by Id
	public Candidate searchById(int id) {
		// TODO Auto-generated method stub
		if(dao.findById(id)==null) {
			throw new CandidateNotFoundException("Candidate does not exists..!!");
		}
		return dao.findById(id);
	}

}

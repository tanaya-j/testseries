package com.cg.testseriesjpa.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;

import com.cg.testseriesjpa.dto.Assigner;
import com.cg.testseriesjpa.exception.CandidateNotFoundException;
import com.cg.testseriesjpa.exception.TestNotFoundException;
import com.cg.testseriesjpa.util.DbUtil;

/*
 * This class implements the test assigner repository interface*/
public class TestAssignerRepositoryImp implements TestAssignerRepository {
static EntityManager em;
	public TestAssignerRepositoryImp() {
          em=DbUtil.em;
	}
	/*This method saves the assigned test .If the candidate is already assigned a test then second test cannot
	 * be assigned to the same candidate*/
	public Assigner save(Assigner assigner) {
		
		//Query query=em.createQuery("");
		
		em.getTransaction().begin();
		em.persist(assigner);
		em.getTransaction().commit();
		return assigner;}
		
}

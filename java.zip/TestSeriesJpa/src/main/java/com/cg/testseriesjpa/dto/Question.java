package com.cg.testseriesjpa.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



/*
 * This is bean class for Question it includes id content options correct options
 * Constructor,getter setter ,toString is defined
 * last Modified 06/05/2019
 * Author:Tanaya Jadhav*/
@Entity
@Table(name="Question")
public class Question {
	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private int id;//primary key
	@Column(name="Content")
	private String content;
	@Column(name="optionA")
	private String optionA;
	@Column(name="optionB")
	private String optionB;
	@Column(name="optionC")
	private String optionC;
	@Column(name="correct_option")
	private String correctOption;
	/*@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="test_id")*/
	//private Test test;
	
	public Question() {}

	public Question( String content, String optionA, String optionB, String optionC, String correctOption) {
		super();
	
		//this.number = number;
		this.content = content;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.correctOption = correctOption;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getOptionA() {
		return optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getCorrectOption() {
		return correctOption;
	}

	public void setCorrectOption(String correctOption) {
		this.correctOption = correctOption;
	}

	@Override
	public String toString() {
		return "Question [id=" + id + ",  content=" + content + ", optionA=" + optionA
				+ ", optionB=" + optionB + ", optionC=" + optionC + ", correctOption=" + correctOption + "]";
	}
}

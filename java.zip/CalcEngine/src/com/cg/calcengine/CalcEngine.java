package com.cg.calcengine;

public class CalcEngine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		double[] leftVals= {100.0d ,50.0d ,25.0d , 5.0d };
		double[] rightVals= {10.0d ,3.0d ,6.0d , 4.0d };
		char[] opCodes= {'a','s','m','d'};
		double[] results= new double[opCodes.length];
	   
		
		//double val1 = 50.0d;
		//double val2 = 10.0d;
		//double result;
		//char opCode ='t';
		
		for(int i=0 ; i<opCodes.length ; i++) {
			switch(opCodes[i]) {
			case 'a' :
			results[i]=leftVals[i]+rightVals[i];
			
			break;
			case 's': 
			results[i]=leftVals[i]-rightVals[i];
			break;
			case 'd' :
			results[i]=rightVals[i] != 0.0d ? leftVals[i]/rightVals[i] : 0.0d;
			break;
		
			case 'm' :
			results[i]=leftVals[i]*rightVals[i];
			break;
		default:
			System.out.println("Invalid opcode");
			results[i]=0.0d;
			break;
		     
		    }
		}
		
		for(double theResult :results) {
			System.out.print("result is:");
			System.out.println(theResult);
		}
		
	}
}

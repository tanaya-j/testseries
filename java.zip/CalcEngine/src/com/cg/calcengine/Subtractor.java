package com.cg.calcengine;

public class Subtractor extends CalculateBase {


	public Subtractor() {}
	
	public Subtractor(double leftVals,double rightVals) {
		super(leftVals,rightVals);
	}
	
	

	@Override
	public void calculate() {
 
		// TODO Auto-generated method stub
		double value=getLeftVals() - getRightVals();
       setResults(value);	
	}
}


package com.cg.calcengine;

public enum MathCommand {

	Add,
	Subtract,
	Multiply,
	Divide
}

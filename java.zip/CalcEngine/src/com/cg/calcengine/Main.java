 package com.cg.calcengine;

public class Main {

	public static void main(String[] args) {
		
	   String[] Statements= {
			   "add 10 5",
			   "subtract 10 5",
			   "multiply 10 5","divide 10 5"};
			   
	   
		
		CalculateHelper helper=new CalculateHelper();
		for(String statement:Statements) {
			helper.process(statement);
			System.out.println(helper);
		}
	   
		System.out.println();
		System.out.println("USing inheritence");
		System.out.println();
		
		CalculateBase[] calculators= {
				new Adder(10,5),new Subtractor(10,5),new Division(10,5),new Multiplier(10,5)
				
		};
		
		for(CalculateBase calculator:calculators) {
			calculator.calculate();
			System.out.println("result is:");
			System.out.println(calculator.getResults());
		}
	}
	}
		// TODO Auto-generated method stub

		/*MathEquation[] equations= new MathEquation[4]; 
		equations[0] =new MathEquation('a',100.0d ,50.0d);
		equations[1] =new MathEquation('s',10.0d ,3.0d);
		equations[2] =new MathEquation('d',25.0d , 5.0d);
		equations[3] =new MathEquation('m',6.0d , 4.0d);
				*/
				//for(i=0;i<opcodes.length;i++) {}
		
		/*
		for(MathEquation equation :equations) {
			equation.execute();
			System.out.print("result is:");
			System.out.println(equation.getresults());
		}*/
		
		
	
	
	/*public static MathEquation create(double leftVal,double rightVal,char opCode) {
		MathEquation equation = new MathEquation(); 
		equation.setleftVals(leftVal);
		equation.setrightVals(rightVal);
		equation.setopCodes(opCode);
		
		return  equation;*/
		
		


 
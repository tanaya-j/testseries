package com.cg.calcengine;

public class Adder extends  CalculateBase{

	public Adder() {}
	
	public Adder(double leftVals,double rightVals) {
		super(leftVals,rightVals);
	}
	
	

	@Override
	public void calculate() {
 
		// TODO Auto-generated method stub
		double value=getLeftVals() +getRightVals();
       setResults(value);	
	}
}  
package com.cg.calcengine;

public class Division extends CalculateBase {


	public Division() {}
	
	public Division(double leftVals,double rightVals) {
		super(leftVals,rightVals);
	}
	
	

	@Override
	public void calculate() {
 
		// TODO Auto-generated method stub
		double value=getLeftVals() / getRightVals();
       setResults(value);	
	}
}

 package com.cg.calcengine;

public class MathEquation {
	
    private double leftVals;
    private	double rightVals;
    private char opCodes;
    private double results;
   
    public double getleftVals() {return leftVals;}
    public void setleftVals(double leftVal) {
    	this.leftVals=leftVal;
    	}
    
    
    public double getrightVals() {return rightVals;}
    public void setrightVals(double rightVal) {
    	this.rightVals=rightVal;
    	}
    
    public char getopCodes() {return opCodes;}
    public void setopCodes(char opCode) {
    	this.opCodes=opCode;
    	}
    
    public double getresults() {
    	return results;
    	}
    
    
     public MathEquation() {}
     
     public MathEquation(char opCode) {
    	 this.opCodes=opCode;
     }
     
     public MathEquation(char opCode,double leftVals,double rightVals ) {
    	 this(opCode);
    	 this.leftVals=leftVals;
    	 this.rightVals=rightVals;
    	
     }
    
	public void execute() {
		switch(opCodes) {
		case 'a' :
		results=leftVals+rightVals;
		
		break;
		case 's' : 
		results=leftVals-rightVals;
		break;
		case 'd' :
		results=rightVals != 0.0d ? leftVals/rightVals : 0.0d;
		break;
	
		case 'm' :
		results=leftVals*rightVals;
		break;
	default:
		System.out.println("Invalid opcode");
		results=0.0d;
		break;
	     
	    }
	}

}

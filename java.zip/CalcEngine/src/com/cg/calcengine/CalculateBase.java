package com.cg.calcengine;

public abstract class CalculateBase {
	
	    private double leftVals;
	    private	double rightVals;
	   // private char opCodes;
	    private double results;
		public double getLeftVals() {
			return leftVals;
		}
		public void setLeftVals(double leftVals) {
			this.leftVals = leftVals;
		}
		public double getRightVals() {
			return rightVals;
		}
		public void setRightVals(double rightVals) {
			this.rightVals = rightVals;
		}
		public double getResults() {
			return results;
		}
		public void setResults(double results) {
			this.results = results;
		}
	    
		public CalculateBase() {}
		public CalculateBase(double leftVals, double rightVals) {
			super();
			this.leftVals = leftVals;
			this.rightVals = rightVals;
			
		}
		
		public abstract void calculate();
	    

}

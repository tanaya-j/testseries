package com.cg.collection.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.collection.dto.Employee;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Set<String> myList=new TreeSet<String>();
		
		myList.add("4");
		myList.add("p");
		myList.add("a");
		myList.add("A");
		myList.add("Q");
		myList.add("z");
		myList.add("1");
		
		*/
		System.out.println("myList");
        A.getAll();
		
		/*Set<Employee> mySet=new HashSet<Employee>();
		
		
		Employee emp=new     Employee(1, "tj",10000);
		Employee empOne=new  Employee(2, "T",20000);
		Employee empTwo=new  Employee(3, "abc",30000);
		
        
        mySet.add(emp);
        mySet.add(empOne);
        mySet.add(empTwo);
       
       
        List<Employee> sortedList = new ArrayList<Employee>(mySet);
        Collections.sort(sortedList); 
        
        System.out.println(sortedList);*/
    
	}
}

class A{
	
	public static void getAll()
	{
		System.out.println("abc");
	}
}

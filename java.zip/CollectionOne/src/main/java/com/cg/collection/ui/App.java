package com.cg.collection.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.cg.collection.dto.Employee;
//import com.cg.collection.dto.EmployeeC;
import com.cg.collection.dto.EmployeeC;

public class App 
{
    public static void main( String[] args )
    {
       Employee <Integer,Double> emp= new Employee<Integer,Double>(1, "tana", 1000.0);
       Employee<BigInteger,BigDecimal> empOne=new Employee<BigInteger,BigDecimal>(new BigInteger("2"), "yasha", new BigDecimal(2000.0));
       Employee emptwo=new Employee(3, "aishu", 3000);
       Employee empthree=new Employee(4, "sona", 3000);
       Map<Integer,Employee> myMap=new HashMap<Integer,Employee>();
       
       myMap.put(1, emp);
       myMap.put(2, empOne);
       myMap.put(3, emptwo);
       myMap.put(4, empthree);
       
      Collection<Employee> myColl=myMap.values();
      List<Employee> empList=new ArrayList<Employee>(myColl);
      Collections.sort(empList, new EmployeeC());
      
      for(Employee employee:empList)
      {
    	  System.out.println("Name is "+employee.getName());
      }
       
    //   Set<Employee> mySet=new HashSet<Employee>(myMap.values());
       
        
     
         
         //Iterator it=mySet.iterator();
       
          
       /*  Collections.sort(mySet, new EmployeeC());
         for(Integer it:myMap.keySet())
           {
    	   System.out.println(myMap.get(it));
           }
       
       */
       }
}

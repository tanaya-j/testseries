package com.cg.collection.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MyApp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jbdc:mysql://localhost/test", "root", "Capgemini123");	
			/*PreparedStatement pstmt=conn.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
			pstmt.setInt(1, 1001);
			pstmt.setString(2, "xyz");
			pstmt.setDouble(3, 10000.0);
			
			pstmt.executeUpdate();*/
			
			PreparedStatement pstmt=conn.prepareStatement("SELECT emp_id,emp_name,emp_salary FROM EMPLOYEE ");
			ResultSet result=pstmt.executeQuery();
			
			while(result.next()) {
				int id=result.getInt("emp_id");
				
			}
			//System.out.println("connection done..");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Driver not loaded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("not connected");
		}
	 }
}

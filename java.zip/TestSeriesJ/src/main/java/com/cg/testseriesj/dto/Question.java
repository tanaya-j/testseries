package com.cg.testseriesj.dto;

public class Question {

}

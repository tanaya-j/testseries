package com.cg.testseriesj.dto;

public class Assigner {

}

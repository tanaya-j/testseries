package com.cg.testseriesj.dto;

public class Test {

}

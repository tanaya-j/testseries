package com.cg.testseriesm.dto;

import java.math.BigInteger;
import java.util.List;

/*
 * This is bean class for Test it includes id ,name,total questions,total marks,list of questions
 * Constructor,getter setter ,toString is defined*/
public class Test {
	
	private int id;//primary key
	private String name;
	private BigInteger totalquestions;
	private BigInteger totalMarks;
	private List<Question> questions;
	
	public Test() {}

	public Test(int id, String name, BigInteger totalquestions, BigInteger totalMarks, List<Question> questions) {
		super();
		this.id = id;
		this.name = name;
		this.totalquestions = totalquestions;
		this.totalMarks = totalMarks;
		this.questions = questions;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getTotalquestions() {
		return totalquestions;
	}

	public void setTotalquestions(BigInteger totalquestions) {
		this.totalquestions = totalquestions;
	}

	public BigInteger getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(BigInteger totalMarks) {
		this.totalMarks = totalMarks;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Test [id=" + id + ", name=" + name + ", totalquestions=" + totalquestions + ", totalMarks=" + totalMarks
				+ ", questions=" + questions + "]";
	}
	
	
	
}

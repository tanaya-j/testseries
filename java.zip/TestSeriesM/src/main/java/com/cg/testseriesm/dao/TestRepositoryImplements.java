package com.cg.testseriesm.dao;

import com.cg.testseriesm.util.DbUtil;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.cg.testseriesm.dto.Question;
import com.cg.testseriesm.dto.Test;
import com.cg.testseriesm.exception.TestNotFoundException;

public class TestRepositoryImplements implements TestRepository {

	//saves the created test in the database
	public Test saveTest(Test test) {
		// TODO Auto-generated method stub
	
		
		Connection con=DbUtil.getConnection();//gets connection to database
		String query_insert = "INSERT INTO test VALUES(?,?,?,?)";//query to insert into table test
		PreparedStatement pstmt=null;//used to execute dynamic queries
		
		try {
			pstmt=con.prepareStatement(query_insert);
			pstmt.setInt(1, test.getId());
			pstmt.setString(2, test.getName());
			pstmt.setString(3, test.getTotalquestions().toString());
			pstmt.setString(4,test.getTotalMarks().toString());
			pstmt.executeUpdate();
			
		/*	try {*/
			for(Question q :test.getQuestions()) {
				pstmt=con.prepareStatement("INSERT INTO question values(?,?,?,?,?,?,?)");
			    
			    	pstmt.setInt(1, q.getId());
			   
			    pstmt.setString(2,q.getContent());
			    pstmt.setString(3,q.getOptionA());
			    pstmt.setString(4,q.getOptionB());
			    pstmt.setString(5,q.getOptionC());
			    pstmt.setString(6,q.getCorrectOption());
			    pstmt.setInt(7,test.getId());
			    pstmt.executeUpdate();
			}
			}/*catch(SQLException e) {
				throw new TestNotFoundException("question with this id already exists..!!!!");
			}
		}*/ catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new TestNotFoundException("question with this id  already exists..!!");
		}
		finally {
       	 try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
				throw new TestNotFoundException("Connection not closed...");
			}
        }
		
		return null;
	}

	//finds the test by its name from the database
	public Test findByName(String testName) {
	
		Connection con=DbUtil.getConnection();
		List<Question> myQuestions=new ArrayList<Question>();
		String query_select="select t.testId,t.name,t.totalquestion,t.totalMarks,q.QuestionId,q.content,q.optionA,q.optionB,q.optionC,q.correctoption,q.test_id  from test t INNER JOIN question q ON t.testId =q.test_id where name=? ";
		PreparedStatement pstmt=null;
		ResultSet rs=null;Test test=new Test();
		
		try {
			pstmt=con.prepareStatement(query_select);
			pstmt.setString(1, testName);
			rs=pstmt.executeQuery();
			rs.beforeFirst();
			if(rs!=null) {
				while(rs.next())
				{				
					Question question=new Question();
					test.setId(rs.getInt("testId"));
					test.setName(rs.getString("name"));
					test.setTotalMarks(rs.getBigDecimal("totalmarks").toBigInteger());
					test.setTotalquestions(rs.getBigDecimal("totalquestion").toBigInteger());
					
					
                    question.setId(rs.getInt("QuestionId"));
                    question.setContent(rs.getString("content"));
                    question.setOptionA(rs.getString("optionA"));
                    question.setOptionB(rs.getString("optionB"));
                    question.setOptionC(rs.getString("optionC"));
                    question.setCorrectOption(rs.getString("correctoption"));
                   
                    test.setQuestions(myQuestions);
	            	myQuestions.add(question);
	              }
			}
		}catch (SQLException e) {
				// TODO Auto-generated catch block
			throw new TestNotFoundException("Test not created..");
			}
		
		
		finally {
	       	 try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					
					throw new TestNotFoundException("Connection not closed...");
				}
	        }
		if(test.getName()==null) {
			throw new TestNotFoundException("Test Not Created....!!!!!!");
		}
		return test;
		}

	
	public Test findById(int id) {
		// TODO Auto-generated method stub
		
		Connection con=DbUtil.getConnection();
		String query_insert="select * from test where test test_id= ?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Test t =new Test();List<Question> myQuestions=new ArrayList<Question>();
		
		try {
			pstmt=con.prepareStatement(query_insert);
			pstmt.setInt(1, id);
			
			rs =pstmt.executeQuery();
			rs.next();
			t.setId(rs.getInt("testId"));
			t.setName(rs.getString("name"));
			t.setTotalMarks(rs.getBigDecimal("totalmarks").toBigInteger());
			t.setTotalquestions(rs.getBigDecimal("totalquestion").toBigInteger());
			
			Question question=new Question();
			 question.setId(rs.getInt("QuestionId"));
             question.setContent(rs.getString("content"));
             question.setOptionA(rs.getString("optionA"));
             question.setOptionB(rs.getString("optionB"));
             question.setOptionC(rs.getString("optionC"));
             question.setCorrectOption(rs.getString("correctoption"));
            
             t.setQuestions(myQuestions);
             myQuestions.add(question);
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new TestNotFoundException("Test with this id already exits..");
		}
		return t;
	}
}
		


package com.cg.testseriesm.services;

import com.cg.testseriesm.dao.TestRepository;
import com.cg.testseriesm.dao.TestRepositoryImplements;
import com.cg.testseriesm.dto.Test;
import com.cg.testseriesm.exception.TestNotFoundException;

/*This class is implementation of test service interface which implements create test ,search test 
 * by name and id methods..!*/
public class TestServiceImplements implements TestService{
TestRepository dao;
	
	public TestServiceImplements() {
		
		dao= new TestRepositoryImplements();
	}
	
	//creates the test
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		return dao.saveTest(test);
	}

	//search test by name
	public Test searchTestByName(String testName) {
		// TODO Auto-generated method stub
				return dao.findByName(testName);
	}

	//search test by Id
	public Test searchTestById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}

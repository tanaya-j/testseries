package com.cg.testseriesm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.testseriesm.dto.Candidate;
import com.cg.testseriesm.dto.Question;
import com.cg.testseriesm.exception.CandidateNotFoundException;
import com.cg.testseriesm.exception.TestNotFoundException;

import com.cg.testseriesm.util.DbUtil;

/*
 * This is a implementation of candidate repository which implements */
public class CandidateRepositoryImp implements CandidateRepository {


	
	//saves the candidate
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		Connection con=com.cg.testseriesm.util.DbUtil.getConnection();
		String query_insert = " INSERT INTO candidate VALUES(?,?)";
		PreparedStatement pstmt=null;
				
			try {
			    pstmt=con.prepareStatement(query_insert);
				pstmt.setInt(1, candidate.getId());
				pstmt.setString(2, candidate.getName());
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new CandidateNotFoundException("Candidate with this Id already exists....!!!!!!!!!");
			}
             finally {
            	 try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					throw new CandidateNotFoundException("Connection not closed...");
				}
             }
			return null;
	}

	//finds the candidate by its Id
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		Connection con=DbUtil.getConnection();
		String query="SELECT * FROM candidate where CandidateId= ?";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Candidate candidate=new Candidate();
		try {
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			rs.isBeforeFirst();
			if(rs!=null) {
				while(rs.next())
				{				
					
					candidate.setId(rs.getInt("CandidateId"));
					candidate.setName(rs.getString("name"));
					
		        }
		
	       }
			
}catch (SQLException e) {
	// TODO Auto-generated catch block
	throw new CandidateNotFoundException("test is already assigned to this candidate..!");
}finally {
  	 try {
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new TestNotFoundException("Connection not closed...");
		}
   }
	if(candidate.getId()!=id) {
		throw new CandidateNotFoundException("Candidate Not found...!!!");
	}
		return candidate;
	}
}
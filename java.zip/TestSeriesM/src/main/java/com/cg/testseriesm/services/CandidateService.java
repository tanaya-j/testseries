package com.cg.testseriesm.services;

import com.cg.testseriesm.dto.Candidate;

/*This a candidate service interface which includes add candidates and serachBy  id method*/

public interface CandidateService {
  public Candidate addCandidate(Candidate candidate);//adds the candidate
  public Candidate searchById(int id);//search the candidate by its id
}

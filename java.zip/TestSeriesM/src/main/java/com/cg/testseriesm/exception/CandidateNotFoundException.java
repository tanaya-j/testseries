package com.cg.testseriesm.exception;

public class CandidateNotFoundException extends RuntimeException {

	public  CandidateNotFoundException() {super();}
	public  CandidateNotFoundException(String msg) {super(msg);}
	
}

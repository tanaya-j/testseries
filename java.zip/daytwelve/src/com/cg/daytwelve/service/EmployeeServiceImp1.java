package com.cg.daytwelve.service;

import java.util.List;

import com.cg.daytwelve.dao.EmployeeDao;
import com.cg.daytwelve.dao.EmployeeDaoImp1;
import com.cg.daytwelve.dao.EmployeeException;
import com.cg.daytwelve.dto.Employee;

public class EmployeeServiceImp1 implements EmployeeServices{
EmployeeDao dao;

public EmployeeServiceImp1() {
	dao= new EmployeeDaoImp1();
}

	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		emp.setSalary(emp.getSalary()+(0.1*emp.getSalary()));
		dao.save(emp);
		
	}

	@Override
	public List<Employee> searchBy(String name) {
		// TODO Auto-generated method stub
		
		return dao.findByName(name);
	}
	

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public Employee update(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		List<Employee> empid=dao.findById(id);
		for(Employee empOne :empid)
		 empOne.setSalary(empOne.getSalary()+(0.1*empOne.getSalary()));
	return null;
	}

	@Override
	public void sortAll() {
		// TODO Auto-generated method stub
		
	}
}

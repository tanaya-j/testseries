package com.cg.daytwelve.service;

import java.util.List;

import com.cg.daytwelve.dto.Employee;

public interface EmployeeServices {

	public void addEmployee(Employee emp);
	public List<Employee> searchBy(String name);
	public List<Employee> showAll();
	public Employee update(int id);
	public void sortAll();
	 
	
	
}

package com.cg.daytwelve.dao;

import java.util.List;

import com.cg.daytwelve.dto.Employee;

public interface EmployeeDao {

	public Employee save(Employee emp);
	public List<Employee> findByName(String name);
	public List<Employee> findById(int id);
	public List<Employee> showAll();

	
	
}

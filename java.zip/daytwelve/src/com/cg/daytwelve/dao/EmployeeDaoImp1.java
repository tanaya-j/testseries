package com.cg.daytwelve.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.daytwelve.dto.Employee;

public class EmployeeDaoImp1 implements EmployeeDao {

	
	List<Employee> empData;
	public EmployeeDaoImp1() {
		 empData=new ArrayList<Employee>();
	}
	
	@Override
	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		  empData.add(emp);
		  
		  return emp;
	}

	@Override
	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		List<Employee> empSearch=new ArrayList();
		for (Employee employee : empData) {
			if(employee.getName().equals(name)) {
				empSearch.add(employee);
			}
			
		}
		return empSearch;
	}

	@Override
	public List<Employee> findById(int id) throws EmployeeException{
		// TODO Auto-generated method stub
		List<Employee> empSearch1=new ArrayList();
		for (Employee employee : empData) 
			if(employee.getId()==id) {
				empSearch1.add(employee);
				return  empSearch1;
			}
			else {
				    throw new EmployeeException("id not found");
			      }return null;
	
		}
	
	

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return empData;
	}

}

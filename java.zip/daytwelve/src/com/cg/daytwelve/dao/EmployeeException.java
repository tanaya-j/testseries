package com.cg.daytwelve.dao;

public class EmployeeException extends RuntimeException{

	public EmployeeException() {
		super();
	}
	
	public EmployeeException(String msg) {
		super(msg);
	}
}

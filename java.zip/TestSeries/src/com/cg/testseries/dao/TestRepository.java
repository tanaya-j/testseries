package com.cg.testseries.dao;

import java.util.List;

import com.cg.testseries.dto.Test;



public interface TestRepository {
	public Test saveTest(Test test);
	public Test findByName(String testName);
}

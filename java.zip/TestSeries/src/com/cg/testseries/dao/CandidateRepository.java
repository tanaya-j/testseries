package com.cg.testseries.dao;

import java.util.List;

import com.cg.testseries.dto.Candidate;

public interface CandidateRepository {

	public Candidate saveCandidate(Candidate candidate);
	public Candidate findById(int id);
}

package com.cg.testseries.dao;

public class TestNotFoundException extends RuntimeException {

	 TestNotFoundException() {
		
	}
	
     TestNotFoundException(String msg) {
		super(msg);
	}
}

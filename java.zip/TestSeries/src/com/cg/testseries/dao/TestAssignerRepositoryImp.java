package com.cg.testseries.dao;

import java.util.List;

import com.cg.testseries.dto.Assigner;
import com.cg.testseries.dto.Candidate;
import com.cg.testseries.dto.Test;
import com.cg.testseries.util.DBUtilAssigner;

public class TestAssignerRepositoryImp implements TestAssignerRepository {

	

	
	@Override
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
       DBUtilAssigner.assigner.add(assigner);
		return assigner;
	}

}

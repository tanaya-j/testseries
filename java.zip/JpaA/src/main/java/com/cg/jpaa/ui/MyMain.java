package com.cg.jpaa.ui;

import java.util.Scanner;

import com.cg.jpaa.dto.AuthorServices;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr = new Scanner(System.in);
		
		//em.getTransaction().begin();  
	
		int ch;
	     // Project proj = new Project();
	    AuthorServices service=new AuthorServices();
	     do {
	    	 print();
	    	 System.out.println("Enter your choice");
	    		ch = scr.nextInt();

	     switch(ch) {
	    	 case 1:
	    		 System.out.println("Enter id:");
	    		 int id = scr.nextInt();
	    		 System.out.println("Enter name:");
	    		 String name = scr.next();
	    		 System.out.println("Enter contact:");
	    		 long contact=scr.nextLong();
	    		 service.create(id, name, contact);
	    		 
		       break;
		       
 }
	   	 
	     }while(ch!=0);
	    // em.getTransaction().commit();  
	     }
	
	public static void print() {
		System.out.println("Add    author");
		System.out.println("Update author");
		System.out.println("Delete author");
		System.out.println("Search author");
	}
	}



package com.cg.jpaa.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.jpaa.dto.Author;

public class AuthorServices {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("author");  
    EntityManager em=emf.createEntityManager();  
  
    public void create(int id, String name, long contact) {
    	Author author=new Author(id,name,contact);
		em.getTransaction().begin();  
		em.persist(author);
	    em.getTransaction().commit();
	}
    
}

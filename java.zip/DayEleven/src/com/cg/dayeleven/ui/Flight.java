package com.cg.dayeleven.ui;

public class Flight {

	public static void main(String[] args) {
		
		
	}
}

package com.cg.dayeleven.ui;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Datee {

	public static void main(String[] args) throws ParseException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Date ");

		String st =scanner.next();
		
		SimpleDateFormat format=new SimpleDateFormat("yyyy/mm/dd");
		Date givenDate=format.parse(st);
		
		System.out.println(givenDate.getDate());
	}

}

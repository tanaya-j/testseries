package com.cg.dayeleven.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class LocaleD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*LocalDateTime local=LocalDateTime.now();
		System.out.println(local.plusDays(2));
		
		ZonedDateTime zone=ZonedDateTime.now(ZoneId.of("America/Chicago"));
		System.out.println(zone);*/
		
		
	}

}

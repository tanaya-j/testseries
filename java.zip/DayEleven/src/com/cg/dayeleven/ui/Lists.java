package com.cg.dayeleven.ui;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Lists {
public static void main(String[] args) {

      List<String> myList =new LinkedList<String>();
      myList.add("A");
      myList.add("B");
      myList.add("C");
      myList.add("A");
      
      System.out.println(myList.set(3,"D"));
      System.out.println(myList);
      
	
}
}
 


/*  	
     List<String> myList=new LinkedList<String>();
	 myList.add("GG");
	 myList.add("1");
	 myList.add("true");
	
	 for(String list:myList)
	 {
		 System.out.println(list);
	 }
         System.out.println("");


	 Iterator<String> it= myList.iterator();
	 
	 while(it.hasNext()) {
		 System.out.println(it.next());
	 }*/
	 

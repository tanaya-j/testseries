package com.cg.Demo.service;

public class Calculator {

	public double addNumber(double one,double two) {
		return one+two;
	}
	
	public double subNumber(double one,double two) {
		return one-two;
	}
	
	public double mulNumber(double one,double two) {
		return one*two;
	}
	
	public double divNumber(double one,double two) {
		return one/two;
	}
}

package com.cg.Demo.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Ignore;
//import org.junit.Test;
import org.junit.jupiter.api.Test;

class CalculatorTest {
//int a;
Calculator cal;
   /* @BeforeAll
     public static void beforeAll() {
	System.out.println(" before all");
}*/
	@BeforeEach
	public void doBeforeMyTest() {
      cal=new Calculator();
	}
	@Test
	public void doMyTest() {
		assertEquals(12.0, cal.addNumber(10,2));
	}
	
	@Test
	public void doMyTestOne() {
		assertEquals(8.0, cal.subNumber(10,2));
	}
	
	@Test
	public void doMyTestTwo() {
		assertEquals(20.0, cal.mulNumber(10,2));
	}
	
	@Test
	public void doMyTestThree() {
		assertEquals(5.0, cal.divNumber(10,2));
	}
	
	@AfterEach
	public void doAfterMyTest() {
		
	}
  /*
	@AfterAll
	public static void afterAll() {
		System.out.println(" after all");
	}
*/
}



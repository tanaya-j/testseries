package com.cg.Demo.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;

class Employee {

	@Test
	void test() {
		fail("Not yet implemented");
		
	}


	@After
	void testOne()
	{
		fail("Not yet completed");
	}
	
	@Before
	void testTwo()
	{
		fail("Not yet completed");
	}
}

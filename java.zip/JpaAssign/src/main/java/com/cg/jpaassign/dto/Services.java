package com.cg.jpaassign.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class Services {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("authordemo");  
    EntityManager em=emf.createEntityManager();  
  
    public void create(int id, String name, long contact) {
    	Author author=new Author(id,name,contact);
		em.getTransaction().begin();  
		em.persist(author);
	    em.getTransaction().commit();
	}
    
   /* public void update(int id, String name, double salary, String pname) {
   	 em.getTransaction().begin(); 
   	 Employee emp = em.find(Employee.class, id);
   	 if(emp!=null) {
   		 Project pro=em.find(Project.class, emp.getProj().getId());
   		 pro.setName(pname);
   		 emp.setSalary(salary);
   		 emp.setName(name);
   		 emp.setProj(pro);
   		 em.persist(pro);
   			em.persist(emp);
   			em.getTransaction().commit();
   	 }
    }
    
    public void remove(int id) {
   	 em.getTransaction().begin(); 
   	 Employee remove=em.find(Employee.class, id);
		 em.remove(remove);
		 em.getTransaction().commit();
    }
    
    public void showDetails(int id) {
   	 em.getTransaction().begin();
   	 Employee emp = em.find(Employee.class, id);
   	 if(emp!=null) {
   	 Project pro=em.find(Project.class, emp.getProj().getId());
   	 System.out.println(pro.getName());
   	 System.out.println(pro.getName()); 
		
   	 }
   	 em.getTransaction().commit();
    }*/
}

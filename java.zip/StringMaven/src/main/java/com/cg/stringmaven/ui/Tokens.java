package com.cg.stringmaven.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;

public class Tokens {

	
	public static void main(String[] args) {
		Reader fread = null;
		Writer fwrite = null;
		BufferedReader rbuffer;
		BufferedWriter wbuffer;
		
		
		try {
		 fread = new FileReader("employee.txt");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rbuffer=new BufferedReader(fread);
		
		try {
			fwrite=new FileWriter("employeee.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		wbuffer=new BufferedWriter(fwrite);
		String data=null;
		String data1=null;
		try {
			while((data=rbuffer.readLine())!=null) {
				StringTokenizer str=new StringTokenizer(data , ":");
				 while(str.hasMoreTokens()) {
					 data1=str.nextToken();
					
				 } System.out.println(data1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
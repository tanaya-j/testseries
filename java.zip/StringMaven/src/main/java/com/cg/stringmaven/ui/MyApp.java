package com.cg.stringmaven.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

public class MyApp {
  public static void main(String[] args) {
		// InputStream fread = null;
		//OutputStream fwrite=null;
		 Reader fread = null;
		 Writer fwrite=null;
		 BufferedReader bufReader=null;
		 BufferedWriter bufWriter=null;
           try {
			//fread=new FileInputStream("myread.txt");//for bytes
			//fwrite=new FileOutputStream("mywrite.txt") ;
        	   fread=new FileReader("D:/employeeRead.txt");//character
        	   bufReader=new BufferedReader(fread);
        	   
        	    fwrite=new FileWriter("D:/employeewrite.txt") ;
        	    bufWriter=new BufferedWriter(fwrite);
				String data=null;
				while((data=bufReader.readLine()) !=null) {
					bufWriter.write(data);
			    /* System.out.println(data);
			     char c=(char)data;//to print the characters
			     System.out.println(c);*/
				}
		       } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		} catch (IOException e) {
				// TODO Auto-generated catch block
			System.out.println("File not open");
			} finally {
				
				try {
					bufReader.close();
					bufWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
				System.out.println("not closed");
				}
			}                       
	}
}
//TODO Auto-generated method stub
/*String str=new String ("hello");
String str1="hello";

System.out.println(str==str1);
System.out.println(str.equals(str1));*/

/*String str="CApgemini";
System.out.println(str.substring(0, 3));
StringBuffer st=new StringBuffer("hello");
*/

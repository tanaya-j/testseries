package com.cg.day2.dto;

public class Employee {
	
	private int    empId;
	private String empName;
    private double empSalary;
    private String empDesgn;
    private Project proj;
   // boolean a;
   // float age;
   // private  char b;
    
//default constructor
    public Employee() {
    	
    }
    
    
  //parameter constructor  
    public Employee(int empId, String empName, double empSalary, String empDesgn, Project proj) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSalary = empSalary;
	this.empDesgn = empDesgn;
	this.proj = proj;
}

//getter setter

	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public double getEmpSalary() {
		return empSalary;
	}



	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}



	public String getEmpDesgn() {
		return empDesgn;
	}



	public void setEmpDesgn(String empDesgn) {
		this.empDesgn = empDesgn;
	}



	public Project getProj() {
		return proj;
	}



	public void setProj(Project proj) {
		this.proj = proj;
	}

//to string

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDesgn="
				+ empDesgn + ", proj=" + proj + "]";
	}
	
	

}

	/* public Employee(int id,String name,double sal,boolean a,float age,char b) {
    	
    	this.empId=id;
    	this.empName=name;
    	this.empSalary=sal;
    	//this.b=b;
    	//this.a=a;
    	//this.age=age;
    	
    }
    public void getLogin() {
    	int local;
    	System.out.println("in get login");
    	System.out.println("Id is:"+this.empId);
        System.out.println("Name is:"+this.empName);
        System.out.println("Salary is"+this.empSalary);
        System.out.println("floatis"+this.a);
       // System.out.println(local);
       // System.out.println("boolean is"+this.a);
      // System.out.println("char is"+this.b);
    }
    */
  
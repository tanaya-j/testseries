package com.cg.day2.dto;

public class Project {

	
		private int    ProjId;
		private String ProjName;
	    private String ProjDesc;
	    private double ProjCost;
       // private Emplyoee emp;
	public Project() {
		
	}
	
	
	  public Project(int projId, String projName, String projDesc, double projCost) {
		super();
		ProjId = projId;
		ProjName = projName;
		ProjDesc = projDesc;
		ProjCost = projCost;
	}


	public int getProjId() {
		  return ProjId;
	  }  
	  
	  public void setProjId(int ProjId) {
		  this.ProjId=ProjId;
	  }

	  public String getProjName() {
		  return ProjName;
	  }  
	  
	  public void setProjName(String ProjName) {
		  this.ProjName=ProjName;
	  }
	  
	  public double getProjCost() {
		  return ProjCost;
	  }  
	  
	  public void setProjCost(double ProjCost) {
		  this.ProjCost=ProjCost;
		 }
	 
	  public String getProjDesc() {
		  return ProjDesc;
	  }  
	  
	  public void setProjDesc(String ProjDesc) {
		  this.ProjDesc=ProjDesc;
	  }

	@Override
	public String toString() {
		return "Project [ProjId=" + ProjId + ", ProjName=" + ProjName + ", ProjDesc=" + ProjDesc + ", ProjCost="
				+ ProjCost + "]";
	}
	  
}

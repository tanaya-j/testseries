package com.cg.day2.ui;
import java.util.Scanner;

import com.cg.day2.dto.*;

public class MyApplication 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		Employee emp = new Employee();
		//Employee emp1 = new Employee();
		Project proj=new Project();
		//Project proj1=new Project();
		
		Scanner scr=new Scanner(System.in);
		
		System.out.println("enter the name");
		String name=scr.nextLine();
		System.out.println("enter the employee id");
		int id=scr.nextInt();
		System.out.println("enter the salary");
		double salary=scr.nextDouble();
		System.out.println("enter the desgination");
		String desgn=scr.next();
		
		
		System.out.println("enter the project id");
		int projId=scr.nextInt();
		System.out.println("enter the project name");
		String projName=scr.next();
		System.out.println("enter the cost");
		double projCost=scr.nextDouble();
		System.out.println("enter the description");
		String desc=scr.next();
		
		
	
		/*int id=Integer.parseInt(args[0]);
		String name=args[1];
		double salary=Double.parseDouble(args[2]);
		String Desgn=args[3];
		
		int projId=Integer.parseInt(args[4]);
		String projName=args[5];
		double Cost=Double.parseDouble(args[6]);
		String Desc=args[7];
		*/
		
		emp.setEmpId(id);
		emp.setEmpName(name);
		emp.setEmpSalary(salary);
		emp.setEmpDesgn(desgn);
		
		
		
		proj.setProjName(projName);
		proj.setProjId(projId);
		proj.setProjCost(projCost);
		proj.setProjDesc(desc);
		
		
		/*emp1.setEmpId(2);
		emp1.setEmpName("pooja");
		emp1.setEmpSalary(1000);
		emp1.setEmpDesgn("Analyst");
		
		proj1.setProjName("ABC");
		proj1.setProjId(10);
		proj1.setProjCost(1000);
		proj1.setProjDesc("xyz");
*/
        emp.setProj(proj);
        //emp1.setProj(proj1);
        
        System.out.println(emp);
     //   System.out.println(emp1);
		/*System.out.println("Project id is "+emp.getProj().getProjId());
		System.out.println("Project name is "+emp.getProj().getProjName());
		System.out.println("Project desc is "+emp.getProj().getProjDesc());
		System.out.println("Project cost is "+emp.getProj().getProjCost());
		
		System.out.println("Project id is "+emp.getProj().getProjId());
		System.out.println("Project name is "+emp.getProj().getProjName());
		System.out.println("Project desc is "+emp.getProj().getProjDesc());
		System.out.println("Project cost is "+emp.getProj().getProjCost());*/
	}

}

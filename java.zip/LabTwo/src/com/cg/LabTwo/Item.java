package com.cg.LabTwo;

import java.util.Scanner;

public abstract class Item {

	private int itemId;
	private String title;
	private int Copies;
	
	
	public Item() {}


	public Item(int itemId, String title, int Copies) {
		super();
		this.itemId = itemId;
		this.title = title;
		this.Copies = Copies;
	}


	public int getItemId() {
		return itemId;
	}


	public void setItemId(int itemId) {
		this.itemId = itemId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public int getCopies() {
		return Copies;
	}


	public void setCopies(int Copies) {
		this.Copies =Copies;
	}


	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", title=" + title + ", noOfCopies=" +Copies + "]";
	}
	
	
	public abstract void checkIn();
		
	
	public abstract void checkOut();
	
	public abstract void addItem(); /*{
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the item id: ");
		int itemId=scr.nextInt();
		System.out.println("Enter the item title: ");
		String title=scr.next();
		System.out.println("Enter the no of copies: ");
		int Copies=scr.nextInt();}*/
	
	
}

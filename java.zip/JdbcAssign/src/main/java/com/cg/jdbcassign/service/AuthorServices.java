package com.cg.jdbcassign.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import com.cg.jdbcassign.dto.Author;
import com.cg.jdbcassign.exception.AuthorNotFoundException;
import com.cg.jdbcassign.util.DbUtil;



public class AuthorServices {

	
	public void create(Author author ) {
		
		Connection con=DbUtil.getConnection();
		String query_insert = " INSERT INTO author VALUES(?,?,?,?,?)";
		PreparedStatement pstmt=null;
		
		try {
			pstmt=con.prepareStatement(query_insert);
			pstmt.setInt(1,author.getId());
			pstmt.setString(2, author.getFirstName());
			pstmt.setString(3, author.getMiddleName());
			pstmt.setString(4, author.getLastName());
		    pstmt.setLong(5, author.getContact());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			 try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					throw new AuthorNotFoundException("Connection not closed...");
				}
		}
	}
	
}

package com.cg.jdbcassign.exception;

public class AuthorNotFoundException extends RuntimeException {

	
	public AuthorNotFoundException() {}
	
	public AuthorNotFoundException(String msg) {super(msg);}
}

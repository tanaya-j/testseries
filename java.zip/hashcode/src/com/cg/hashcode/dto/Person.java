package com.cg.hashcode.dto;

public class Person {

	private String name;
	private static int count;
	
	public Person() {}

	public Person(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		System.out.println("HashCode is called");
		/*return 10; return name.charAt(0);*/
		return name.charAt(0);
	}

	@Override
	public boolean equals(Object obj) {
		Person object= (Person)obj;
		count++;
		System.out.println("equals called:"+count);
		
		return this.getName().equals(object);
	}
	
	
	
	
}

package com.cg.hashcode.ui;

import java.util.HashSet;
import java.util.Set;
import com.cg.hashcode.dto.Person;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Person p=new Person("tanaya");
      Person p1=new Person("yashashree");
      Person p2=new Person("aishwarya");
      Person p3=new Person("sonal");
      Person p4=new Person("rutuja");
      Person p5=new Person("radhika");
      Person p6=new Person("nikita");
      Person p7=new Person("vishnu");
      Person p8=new Person("pradip");
      Person p9=new Person("danish");
      
      Set<Person> mySet=new HashSet<Person>();
      
      mySet.add(p);
      mySet.add(p1);
      mySet.add(p2);
      mySet.add(p3);
      mySet.add(p4);
      mySet.add(p5);
      mySet.add(p6);
      mySet.add(p7);
      mySet.add(p8);
      mySet.add(p9);
      
      }
	}

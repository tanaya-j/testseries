package com.cg.jdbcdemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String driver,url,uname,upass;
		
		try {
			InputStream it=new FileInputStream("resources/jdbc.properties");
			Properties prop=new Properties();
			prop.load(it);
			driver=prop.getProperty("jdbc.driver");
			url=prop.getProperty("jdbc.url");
			uname=prop.getProperty("jdbc.username");
			upass=prop.getProperty("jdbc.password");
			
			
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jbdc:mysql://localhost/test", "root", "Capgemini123");	
			PreparedStatement pstmt=conn.prepareStatement("INSERT INTO EMPLOYEE VALUE(?,?,?)");
			pstmt.setInt(1, 1001);
			pstmt.setString(2, "xyz");
			pstmt.setDouble(3, 10000.0);
			pstmt.executeUpdate();
			//System.out.println("connection done..");
			
		 } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Driver not loaded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("not connected");
		}
	 }
}

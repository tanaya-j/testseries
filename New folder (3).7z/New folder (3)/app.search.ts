import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { Test } from "./app.test";

@Component({
    selector:'search-test',
    templateUrl:'search.html'
})


export class SearchTest{
    constructor(private service:TestService){}
    model:any={};  
    test:Test[];
    name:string; 
   
    searchTest(){
        this.service.searchTestByName(this.name).subscribe((data:any)=>this.test=data);
    }
}
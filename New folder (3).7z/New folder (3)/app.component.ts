﻿import { Component } from '@angular/core';

@Component({
    selector: 'cap',
    templateUrl: 'app.component.html'
})

export class AppComponent { }
import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { FormGroup, FormControl } from "@angular/forms";


@Component({
    selector:'add-cand',
    templateUrl:'addCandidate.html'
})


export class AddCandidate{
 
cand=new FormGroup({
name : new FormControl('')

});  
 


    constructor(private service:TestService){}
    model:any={};   
    addCandidate(){
        console.log(this.model);
        this.service.addCandidates(this.model).subscribe((data:any)=>console.log(data));
    }
}


import { Component } from "@angular/core";
import { TestService } from "./app.testService";
import { Question } from "./app.question";

@Component({
    selector:'add-test',
    templateUrl:'addtest.html'
})


export class AddTest{

    constructor(private service:TestService){}
    model:any={};   
    testdata=false;
    questions:Question[]=[];
    question={
    content:'',
    optionA:'',
    optionB:'',
    optionC:'',
    correctOption:''
};

addQuestion(){
console.log(this.model);
this.testdata=true;
}


addQuestions(){
   this.questions.push(this.question);
   console.log(this.questions);
   this.question={
    content:'',
    optionA:'',
    optionB:'',
    optionC:'',
    correctOption:''
   }
}

    addTest(){
        this.model['questions']=this.questions;
        console.log(this.model);
        this.service.addTests(this.model).subscribe((data=>console.log(data)));
    }
}
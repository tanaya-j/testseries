import { Component } from "@angular/core";
import { TestService } from "./app.testService";


@Component({
    selector:'assign',
    templateUrl:'addassigner.html'
})


export class AddAssigner{
    

    constructor(private service:TestService){}
    model:any={};   
    addAssigner(){
        console.log(this.model);
        this.service.addAssigners(this.model).subscribe((data:any)=>console.log(data));
    }
}

package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dto.Product;


public interface ProductService {

	public void addProduct(Product prod);
	public List<Product> showProduct();
	public Product searchById(int id);
	public Product update(int id);
	public void delete(Product pro);
}

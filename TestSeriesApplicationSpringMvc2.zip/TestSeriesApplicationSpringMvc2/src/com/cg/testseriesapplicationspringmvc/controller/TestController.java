package com.cg.testseriesapplicationspringmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.dto.Question;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.exception.AssignerException;
import com.cg.testseriesapplicationspringmvc.exception.CandidateAlreadyexistException;
import com.cg.testseriesapplicationspringmvc.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationspringmvc.exception.TestAlreadyExitsException;
import com.cg.testseriesapplicationspringmvc.exception.TestAssignedException;
import com.cg.testseriesapplicationspringmvc.exception.TestNotFoundException;
import com.cg.testseriesapplicationspringmvc.service.CandidateService;
import com.cg.testseriesapplicationspringmvc.service.TestAssignerService;
import com.cg.testseriesapplicationspringmvc.service.TestService;
/*
 * This is a controller class
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */
@Controller
public class TestController {

	@Autowired
	CandidateService service;
	@Autowired
	TestService tservice;
	@Autowired
	TestAssignerService aservice;
	
    Test t;
	
    
    
   /* This method map to http://localhost:9090/testseriesapplicationspringmvc/main
    		 * 
    		 * @return ModelAndView
    		 * 
     * */ 
 //  @GetMapping(value="main")
    @RequestMapping(value="main" , method=RequestMethod.GET)
	public String listPage() {
		return "main";
		}

    
   
   /* This method map to http://localhost:9090/testseriesapplicationspringmvc/create
    		 * @param @ModelAttribute test
    		 * @return ModelAndView
    		 * 
    		 * */ 
   @GetMapping(value="create")
	public ModelAndView getcreateTest(@ModelAttribute("test") Test test) {
		 return new ModelAndView("createTest");
	}
	
   /* This method map to http://localhost:9090/testseriesapplicationspringmvc/createTest
	 * @param @ModelAttribute test
	 * @return ModelAndView
	 * 
	 * */ 
	@PostMapping("createTest")
	public ModelAndView createTest(@ModelAttribute("test") Test test) {
		this.t=test;
		//Test t=tservice.createMyTest(test);
		return new ModelAndView("addq");
		
	}
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/addq
	 
	 * @return ModelAndView
	 * 
	 * */ 
	@GetMapping(value="addmore")
	public ModelAndView getque() {
		 return new ModelAndView("addq");
	}
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/addq
	 * @param @RequestParam content,optionA,optionB,optionC,correctOption
	 * @return ModelAndView
	 * 
	 * */ 
	@PostMapping("addq")
	public ModelAndView question(/*@RequestParam("id") int id,*/@RequestParam("content") String content,
			@RequestParam("optionA") String optionA,@RequestParam("optionB") String optionB,@RequestParam("optionB") String optionC,
			@RequestParam("correctOption") String correctOption) {
		Question  q=new Question();
		//q.setId(id);
		q.setContent(content);
		q.setOptionA(optionA);
		q.setOptionB(optionB);
		q.setOptionC(optionC);
		q.setCorrectOption(correctOption);
		List<Question> myQuestions=new ArrayList<Question>();
		myQuestions.add(q);
		
		Test ts=new Test();
		ts.setId(t.getId());
		ts.setName(t.getName());
		ts.setTotalMarks(t.getTotalMarks());
		ts.setTotalquestions(t.getTotalquestions());
		ts.setQuestions(myQuestions);
		
		Test aTest=tservice.createMyTest(ts);
		
		return new ModelAndView("addq","key",aTest);
	}
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/find
	 * @return ModelAndView
	 * */ 
	@GetMapping("find")
	public ModelAndView search() {
		return new ModelAndView("searchTest");
	}
	
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/searchTest
	 * @param @ModelAttribute 
	 * @return ModelAndView
	 * 
	 * */ 
	@PostMapping("searchTest")
	public ModelAndView searchTrainee(@RequestParam("name") String name,Model model) {
	Test t=tservice.searchTestByName(name);
	model.addAttribute("keyy",t);
	return new ModelAndView("searched");
			}
	
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/addcandidates
	 * @param @ModelAttribute 
	 * @return ModelAndView
	 * 
	 * */ 
 
	//  @RequestMapping(value="addcandidates" , method=RequestMethod.GET)
	@GetMapping("addcandidates")
	public ModelAndView getAddCandidate(@ModelAttribute("candidate") Candidate c) {
		
		return new ModelAndView("addCand");
		}
	
	
	/* This method map to http://localhost:9090/testseriesapplicationspringmvc/addCand
	 * @param @ModelAttribute Cand
	 * @return ModelAndView
	 * 
	 * */ 
	@PostMapping("addCand")
	 public ModelAndView addcandidate(@ModelAttribute("cand") Candidate c) {
//		 System.out.println(pro);
		Candidate ca=service.addCandidate(c);
		return new ModelAndView("main","key",ca);
	 }
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/assign
	 * @param @ModelAttribute assigner
	 * @return ModelAndView
	 * 
	 * */ 
	@GetMapping("assign")
    public ModelAndView getAssigner(@ModelAttribute("assigner") Assigner assigner) {
		
		return new ModelAndView("assign");
		}
	
	
	 /* This method map to http://localhost:9090/testseriesapplicationspringmvc/assign
	 * @param @ModelAttribute assigner
	 * @return ModelAndView
	 * 
	 * */ 
    @PostMapping("assign")
	public ModelAndView assign(@ModelAttribute("assigner") Assigner assigner) {
	    Assigner assigned=aservice.assignTestToCandidate(assigner);
		return new ModelAndView("assigned","key",assigned);
	}
    
    
    /*This method is to handle test exception
     * @param TestNotFoundException be
     * @return model
     * */
    @ExceptionHandler({TestNotFoundException.class})
    	public ModelAndView handleTestException(TestNotFoundException be) {

    		ModelAndView model = new ModelAndView("error");

    		model.addObject("errMsg", be.getMessage());

    		return model;

    	}  
    
    
    /*This method is to handle candidate exception
     * @param CandidateNotFoundException be
     * @return model
     * */	  
    @ExceptionHandler({CandidateNotFoundException.class})
	public ModelAndView handleCandidateException(CandidateNotFoundException be) {

		ModelAndView model = new ModelAndView("error");

		model.addObject("errMsg1", be.getMessage());

		return model;
    }
 
    
    /*This method is to handle candidate exception
     * @param TestAlreadyExitsException be
     * @return model
     * */	
    @ExceptionHandler({TestAlreadyExitsException.class})
	public ModelAndView TestIdException(TestAlreadyExitsException be) {

		ModelAndView model = new ModelAndView("error");

		model.addObject("errMsg2", be.getMessage());

		return model;

	}   
    
    
    /*This method is to handle candidate exception
     * @param CandidateAlreadyexistException be
     * @return model
     * */	
    @ExceptionHandler({CandidateAlreadyexistException.class})
   	public ModelAndView TestIdException(CandidateAlreadyexistException be) {

   		ModelAndView model = new ModelAndView("error");

   		model.addObject("errMsg3", be.getMessage());

   		return model;

   	}   
    
    
    /*This method is to handle candidate exception
     * @param TestAssignedException be
     * @return model
     * */	
    @ExceptionHandler({TestAssignedException.class})
   	public ModelAndView TestIdException(TestAssignedException be) {

   		ModelAndView model = new ModelAndView("error");

   		model.addObject("errMsg4", be.getMessage());

   		return model;

   	}   
    
  

}

package com.cg.testseriesapplicationspringmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.repository.TestAssignerRepository;
/*
 * This class implements the test assigner service interface
 * last Modified 15/05/2019 Author:Tanaya Jadhav 
*/
@Transactional
@Service
public class TestAssignerImp implements TestAssignerService{

	
	@Autowired
	TestAssignerRepository assignerDao;
	static int assignerId=100;
/* This method assigns the test 
 * @param: assigner
 * @return: assigner   last Modified 15/05/2019  Author:Tanaya Jadhav
*/

	public Assigner assignTestToCandidate(Assigner assigner) {
		// TODO Auto-generated method stub
		assigner.setId(assignerId);
		assignerId++;
		return assignerDao.save(assigner) ;
	}

}

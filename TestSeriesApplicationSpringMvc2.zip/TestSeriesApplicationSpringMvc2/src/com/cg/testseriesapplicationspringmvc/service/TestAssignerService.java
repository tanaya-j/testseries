package com.cg.testseriesapplicationspringmvc.service;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
/*
 * This is the test assigner interface which includes method that assigns test to candidate
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */
public interface TestAssignerService {
	public Assigner assignTestToCandidate(Assigner assigner);
}

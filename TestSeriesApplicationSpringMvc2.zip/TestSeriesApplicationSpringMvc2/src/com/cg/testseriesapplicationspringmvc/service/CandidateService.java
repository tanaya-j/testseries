package com.cg.testseriesapplicationspringmvc.service;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;

public interface CandidateService {
	  public Candidate addCandidate(Candidate candidate);
      public Candidate searchById(int id);
}

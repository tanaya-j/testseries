package com.cg.testseriesapplicationspringmvc.service;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;


/*This a candidate service interface which includes add candidates and searchBy  id method
 * last Modified 22/05/2019
 * Author:Tanaya Jadhav */


public interface CandidateService {
	  public Candidate addCandidate(Candidate candidate);
      public Candidate searchById(int id);
}

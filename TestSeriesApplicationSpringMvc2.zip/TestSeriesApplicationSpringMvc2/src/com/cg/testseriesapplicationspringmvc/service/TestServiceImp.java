package com.cg.testseriesapplicationspringmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.repository.TestRepository;

@Transactional
@Service
public class TestServiceImp implements TestService{

	@Autowired
	TestRepository dao;
	@Override
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		return dao.saveTest(test);
	}

	@Override
	public Test searchTestByName(String testName) {
		// TODO Auto-generated method stub
		return dao.findByName(testName);
	}

}

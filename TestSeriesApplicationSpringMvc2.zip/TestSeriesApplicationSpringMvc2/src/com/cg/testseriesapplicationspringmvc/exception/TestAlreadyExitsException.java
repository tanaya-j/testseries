package com.cg.testseriesapplicationspringmvc.exception;

public class TestAlreadyExitsException extends RuntimeException {
	
	public TestAlreadyExitsException() {}
	public TestAlreadyExitsException(String msg) {
		super(msg);
	}

}

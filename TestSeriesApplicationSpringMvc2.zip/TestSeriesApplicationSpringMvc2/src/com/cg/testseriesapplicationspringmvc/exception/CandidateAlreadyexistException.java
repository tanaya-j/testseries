package com.cg.testseriesapplicationspringmvc.exception;

public class CandidateAlreadyexistException extends RuntimeException {

	public CandidateAlreadyexistException() {
		// TODO Auto-generated constructor stub
	}

	public CandidateAlreadyexistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}

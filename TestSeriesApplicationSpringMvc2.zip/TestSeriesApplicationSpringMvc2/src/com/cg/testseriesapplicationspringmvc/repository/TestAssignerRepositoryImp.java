package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.util.DBUtilAssigner;

@Repository("AssignerRepository")
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
		em.persist(assigner);
		em.flush();
		return assigner;
	}

}

package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationspringmvc.exception.TestNotFoundException;


@Repository("AssignerRepository")
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
		Test test;
		Candidate cand;
		try {
	     test=em.find(Test.class, assigner.getTest().getId());
	     
	      if(test==null) {
	    	  throw new TestNotFoundException("Test with this Id not created..!!");
	      }
		 cand=em.find(Candidate.class, assigner.getCandidate().getId());
		 
		 if(cand==null) {
			 throw new CandidateNotFoundException("Candidate with this Id not found..!!!");
		 }
		if(test!=null && cand!=null)
		{
		em.persist(assigner);
		em.flush();
	    }
		
		}finally {
			if(em!=null)
				em.close();
		}
		return assigner;
}
}
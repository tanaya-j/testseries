package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.cg.testseriesapplicationspringmvc.dto.Question;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.util.DbUtilTest;

@Repository
public class TestRepositoryImp implements TestRepository{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Test saveTest(Test test) {
	Test t=findById(test.getId());
	if(t==null) {
		em.persist(test);
		em.flush();
	}else {
		Question question=new Question();
		question.setId(test.getQuestions().get(0).getId());
		question.setContent(test.getQuestions().get(0).getContent());
		question.setOptionA(test.getQuestions().get(0).getOptionA());
		question.setOptionB(test.getQuestions().get(0).getOptionB());
		question.setOptionC(test.getQuestions().get(0).getOptionC());
		question.setCorrectOption(test.getQuestions().get(0).getCorrectOption());
		question.setTest(test);
		em.persist(question);
		em.flush();
	}
		return test;
	}

	@Override
	public Test findByName(String testName) {
		// TODO Auto-generated method stub
		 Test test =null;
		  try{Query query=em.createQuery("FROM Test t where t.name = :testName ");
		  query.setParameter("testName",testName );
		  test=(Test) query.getSingleResult();}
		  catch(NoResultException ex) {
			  System.out.println("Name Not Present..!!");
		  }
		// em.find(Test.class,testName);
		  return test;
	}

	
	
	public Test findById(Integer testId) {
		Test test=null;
		try{Query query=em.createQuery("FROM Test WHERE id=:testId");
		query.setParameter("testId", testId);
		test=(Test) query.getSingleResult();
		}catch(NoResultException ex) {
			System.out.println("Id Not Present..!!");
		}
		return test;
	}

	@Override
	public Test findById(int id) {
		// TODO Auto-generated method stub
		return em.find(Test.class, id);
	}
}

package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.util.DbUtilTest;

@Repository
public class TestRepositoryImp implements TestRepository{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Test saveTest(Test test) {
		// TODO Auto-generated method stub
		em.persist(test);
		em.flush();
		return test;
	}

	@Override
	public Test findByName(String testName) {
		// TODO Auto-generated method stub
		 Test test =new Test();
		  Query query=em.createQuery("FROM Test t where t.name = :testName ");
		  query.setParameter("testName",testName );
		  test=(Test) query.getSingleResult();
		// em.find(Test.class,testName);
		  return test;
	}

}

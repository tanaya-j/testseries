package com.cg.testseriesapplicationspringmvc.repository;
import com.cg.testseriesapplicationspringmvc.dto.Test;


public interface TestRepository {
	public Test saveTest(Test test);//saves test
	public Test findByName(String testName);//finds test
	public Test findById(int id);//finds test
	
}

package com.cg.demobdd.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {
	
	WebDriver driver;
	By firstName;
	By lastName;
	By email;
	By button;
	
	@Before
	public void init() {
		driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "D://java//DemoBdd//mydriver//chromedriver.exe");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	   
	}
	
	@After
	public void afterAll() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}
	
	
	@Given("^Hotel Booking Page is given$")
	public void hotel_Booking_Page_is_given()  {
	    // Write code here that turns the phrase above into concrete actions
	  driver.get("D:\\java\\DemoBdd\\mypage\\hotelbooking.html");
	  firstName=By.xpath("//*[@id=\"txtFirstName\"]");
	  lastName=By.xpath("//*[@id=\"txtLastName\"]");
	  email=By.xpath("txtEmail");
	  button=By.xpath("//*[@id=\"btnPayment\"]");
	}

	@When("^Clicking on submit button for first name validation$")
	public void clicking_on_submit_button_for_first_name_validation()  {
	    // Write code here that turns the phrase above into concrete actions
	     driver.findElement(button).click();
	}

	@Then("^Alert pops up 'Please fill the first name'$")
	public void alert_pops_up_Please_fill_the_first_name()  {
	    // Write code here that turns the phrase above into concrete actions
	String actualData=driver.switchTo().alert().getText();
	String expectedData="Please fill the first name";
	assertEquals(expectedData, actualData);
	}

	@When("^Clicking on submit button for last name validation$")
	public void clicking_on_submit_button_for_last_name_validation()  {
	    // Write code here that turns the phrase above into concrete actions
     driver.switchTo().alert().dismiss();
     driver.findElement(firstName).sendKeys("tana");
     driver.findElement(button).click();
	}

	@Then("^Alert pops up 'Please fill the last name'$")
	public void alert_pops_up_Please_fill_the_last_name()  {
	    // Write code here that turns the phrase above into concrete actions
		String actualData=driver.switchTo().alert().getText();
		String expectedData="Please fill the last name";
		assertEquals(expectedData, actualData);
	}

	@When("^Clicking on submit button for email validation$")
	public void clicking_on_submit_button_for_email_validation()  {
	    // Write code here that turns the phrase above into concrete actions
		 driver.switchTo().alert().dismiss();
	     driver.findElement(lastName).sendKeys("tana");
	     driver.findElement(button).click();
	}

	@Then("^Alert pops up 'Please fill the email id'$")
	public void alert_pops_up_Please_fill_the_email_id()  {
	    // Write code here that turns the phrase above into concrete actions
		String actualData=driver.switchTo().alert().getText();
		String expectedData="Please fill the email id";
		assertEquals(expectedData, actualData);
	}

	@When("^Clicking on submit button for contact validation$")
	public void clicking_on_submit_button_for_contact_validation()  {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Alert pops up 'Please fill the contact'$")
	public void alert_pops_up_Please_fill_the_contact() {
	    // Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicking on submit button for city validation$")
	public void clicking_on_submit_button_for_city_validation()  {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^Alert pops up 'Please select the city'$")
	public void alert_pops_up_Please_select_the_city()  {
	    // Write code here that turns the phrase above into concrete actions
	 
	}

	@When("^Clicking on submit button for state validation$")
	public void clicking_on_submit_button_for_state_validation()  {
	    // Write code here that turns the phrase above into concrete actions
	
	}

	@Then("^Alert pops up 'Please select the state'$")
	public void alert_pops_up_Please_select_the_state() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}


}

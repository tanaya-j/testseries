package com.cg.testseries.dao;

import java.util.List;

import com.cg.testseries.dto.Assigner;
import com.cg.testseries.dto.Candidate;
import com.cg.testseries.dto.Test;

public interface TestAssignerRepository {
	public Assigner save(Assigner assigner); 
}

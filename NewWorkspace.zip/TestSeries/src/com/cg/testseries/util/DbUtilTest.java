package com.cg.testseries.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.testseries.dto.Question;
import com.cg.testseries.dto.Test;

public class DbUtilTest {

//	public static Map<String,Test> myTests=new HashMap<String,Test>();
	public static List<Test> myTestList=new ArrayList<Test>();
	public static List<Question> myQuestionList=new ArrayList<Question>();
	static {
		
		Question question=new Question();
		List<String> options=new  ArrayList<String>();
		
		question.setNumber(1);
		question.setContent("what is sql?");
		options.add("software query language");
		options.add("structered query language ");
		options.add("structural query language");
		options.add("structure query language");
		question.setOptions(options);
		question.setCorrectOption("structered query language");
		
		myQuestionList.add(question);
      
		Question questionOne=new Question();
		List<String> optionsOne=new  ArrayList<String>();
		
		questionOne.setNumber(2);
		questionOne.setContent("Which is base class for both checked and unchecked exceptions?");
		optionsOne.add("java.lang.Error");
		optionsOne.add("java.lang.Exception");
		optionsOne.add("java.lang.RuntimeError");
		optionsOne.add("java.lang.Throwable");
		questionOne.setOptions(optionsOne);
		questionOne.setCorrectOption("java.lang.Throwable");
		myQuestionList.add(questionOne);
		
		Question questionTwo=new Question();
		List<String> optionsTwo=new  ArrayList<String>();
		
		questionTwo.setNumber(3);
		questionTwo.setContent("how can you prevent class from being extended?");
		optionsTwo.add("By providing only private constructors in the class");
		optionsTwo.add("By declaring the class as private");
		optionsTwo.add("By declaring class as final");
		optionsTwo.add("By  declaring class as abstract");
		questionTwo.setOptions(optionsTwo);
		questionTwo.setCorrectOption("java.lang.Throwable");
		myQuestionList.add(questionTwo);
		
		Question questionThree=new Question();
		List<String> optionsThree=new  ArrayList<String>();
		
		questionThree.setNumber(4);
		questionThree.setContent("which interface does java.util.hashtable implements?");
		optionsThree.add("Collection");
		optionsThree.add("Map");
		optionsThree.add("Set");
		optionsThree.add("List");
		questionThree.setOptions(optionsThree);
		questionThree.setCorrectOption("Map");
		myQuestionList.add(questionThree);
		
		Question questionFour=new Question();
		List<String> optionsFour=new  ArrayList<String>();
		
		questionFour.setNumber(5);
		questionFour.setContent("Which is base class for both checked and unchecked exceptions?");
		optionsFour.add("java.lang.Error");
		optionsFour.add("java.lang.Exception");
		optionsFour.add("java.lang.RuntimeError");
		optionsFour.add("java.lang.Throwable");
		questionFour.setOptions(optionsFour);
		questionFour.setCorrectOption("java.lang.Throwable");
		myQuestionList.add(questionFour);
        
		Question questionFive=new Question();
		List<String> optionsFive=new  ArrayList<String>();
		
		questionFive.setNumber(6);
		questionFive.setContent("hashSet and Hashmsp internally calls which methods on the objects to compare?");
		optionsFive.add("clone() and toString()");
		optionsFive.add("wait() and notify()");
		optionsFive.add("hashCode() and equals()");
		optionsFive.add("none of the above");
		questionFive.setOptions(optionsFive);
		questionFive.setCorrectOption("java.lang.Throwable");
		myQuestionList.add(questionFive);
   }
}

package com.cg.testseries.service;

import java.util.List;

import com.cg.testseries.dao.TestAssignerRepository;
import com.cg.testseries.dao.TestAssignerRepositoryImp;
import com.cg.testseries.dto.Assigner;
import com.cg.testseries.dto.Candidate;
import com.cg.testseries.dto.Test;

public class TestAssignerServiceImp implements TestAssignerService{

	
	TestAssignerRepository assignerDao;
	
	public TestAssignerServiceImp() {
		
		assignerDao=new TestAssignerRepositoryImp();
	}

	@Override
	public Assigner assignTestToCandidate(Assigner assigner) {
		// TODO Auto-generated method stub
		return assignerDao.save(assigner);
	}
	
}

package com.cg.testseries.service;

import java.util.List;

import com.cg.testseries.dto.Test;



public interface TestService {

	
	public Test createMyTest(Test test);
	public Test searchTestByName(String testName);
}

package com.cg.springmvcdemolab.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemolab.dto.Trainee;
import com.cg.springmvcdemolab.service.TraineeService;


@Controller
public class TraineeController {

	@Autowired
	TraineeService service;
	// @RequestMapping(name="login",method=RequestMethod.GET)
	
	@GetMapping(value="login")
	 public String loginPage() {
		 return "mylogin";
	 }

	 @PostMapping("checkLogin")
     public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		// System.out.println("check login");
		 if(user.equals("admin") && pass.equals("tanaya")) {
			 return "listpage";
		 }else {
			 return "error";
		 }
		// return null;
	 }
	 
	 @GetMapping("addpage")
	 public ModelAndView getAddTrainee(@ModelAttribute("tra") Trainee trainee,Model model) {
		 List<String> listOfDomain=new ArrayList<>();
		listOfDomain.add("java");
		listOfDomain.add("mainframe");
		listOfDomain.add("automation testing");
		addRadio(model);
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addTrainee", "dom", listOfDomain);
	 }
	 
	 @GetMapping("showpage")
	 public ModelAndView showTrainee() {
		 List<Trainee> myProducts = service.showAll();
		 return new ModelAndView("showAll", "showtrainee", myProducts);
	 }
	 
	 
	 @PostMapping("addTrainee")
	 public ModelAndView addtrainee(@ModelAttribute("tra") Trainee trainee) {
//		 System.out.println(pro);
		 Trainee trai= service.addTrainee(trainee);
		 return new ModelAndView("success","key",trai);
	 }
	 
	 public void addRadio(Model model) {
			List<String> locationList = new ArrayList<String>();
			locationList.add("Chennai");
			locationList.add("Bangalore");
			locationList.add("Pune");
			locationList.add("Mumbai");
		    model.addAttribute("locations", locationList);
			}
}

package com.cg.springmvcdemolab.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemolab.dto.Trainee;

@Repository
public class TraineeRepositoryImp implements TraineeRepository {

	List<Trainee> traineeList;
	@Override
	public Trainee saveTrainee(Trainee tr) {
		// TODO Auto-generated method stub
		traineeList.add(tr);
		return tr;
	}

	@Override
	public List<Trainee> showAll() {
		// TODO Auto-generated method stub
		return traineeList;
	}

}

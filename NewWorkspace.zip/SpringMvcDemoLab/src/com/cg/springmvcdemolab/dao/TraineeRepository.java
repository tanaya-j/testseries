package com.cg.springmvcdemolab.dao;

import java.util.List;

import com.cg.springmvcdemolab.dto.Trainee;

public interface TraineeRepository {

	public Trainee saveTrainee(Trainee tr);
	public List<Trainee> showAll();
	
}

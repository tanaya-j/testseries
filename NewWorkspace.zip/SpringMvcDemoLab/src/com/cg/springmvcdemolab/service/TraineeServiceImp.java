package com.cg.springmvcdemolab.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemolab.dao.TraineeRepository;
import com.cg.springmvcdemolab.dto.Trainee;

@Service
public class TraineeServiceImp implements TraineeService {

	@Autowired
	TraineeRepository dao;
	
	@Override
	public Trainee addTrainee(Trainee tr) {
		// TODO Auto-generated method stub
		return dao.saveTrainee(tr);
	}

	@Override
	public List<Trainee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

}

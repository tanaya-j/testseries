package com.cg.springmvcdemolab.service;

import java.util.List;

import com.cg.springmvcdemolab.dto.Trainee;

public interface TraineeService {

	public Trainee addTrainee(Trainee tr);
	public List<Trainee> showAll();
	
}

package com.cg.labassignmentspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.labassignmentspring.dao.TraineeDao;
import com.cg.labassignmentspring.dto.Trainee;

@Service
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	TraineeDao dao;
	@Override
	public Trainee addTrainee(Trainee trainee) {
		return dao.saveTrainee(trainee);
	}

	@Override
	public void removeTrainee(Trainee trainee) {
		dao.removeTrainee(trainee);
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
	Trainee t= dao.findTraineeById(trainee.getId());
	t.setName(trainee.getName());
	t.setLocation(trainee.getLocation());
	t.setDomain(trainee.getDomain());
		return t;
	}

	@Override
	public Trainee searchTraineeById(Integer id) {
		return dao.findTraineeById(id);
	}

	@Override
	public List<Trainee> showAllTrainee() {
		return dao.showAllTrainee();
	}


}

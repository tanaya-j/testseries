package com.cg.demowebapplication.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapplication.dto.Product;

public class ProductRepositoryImp implements ProductRepository {

	List<Product> myList=new LinkedList<>();
	@Override
	public void save(Product prod) {
		// TODO Auto-generated method stub
		myList.add(prod);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		System.out.println(myList);
		return myList;
	}

	@Override
	public Product findById(int id) {
		// TODO Auto-generated method stub
		//Product pro=new Product(); 
		for(Product product:myList) {
		if(product.getId()==id) {
			return product;
		}
			
		}
		
		return null;
	}

	@Override
	public void delete(Product pro) {
		// TODO Auto-generated method stub
		myList.remove(pro);
	}

}

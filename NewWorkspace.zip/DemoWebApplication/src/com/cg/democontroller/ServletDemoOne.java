package com.cg.democontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapplication.dto.Product;
import com.cg.demowebapplication.service.ProductService;
import com.cg.demowebapplication.service.ProductServiceImp;

/**
 * Servlet implementation class ServletDemoOne
 */
@WebServlet(urlPatterns= {"/add","/show","/addproduct","/search","/searchProduct","/update","/updateProduct","/delete","/deleteProduct"})
public class ServletDemoOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	ProductService service;
    public ServletDemoOne() {
        super();
        service=new ProductServiceImp() ;
	}
    
    String url;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		String url=request.getServletPath();
		
		if(url.equals("/add")) {
			//AddProduct.jsp
		RequestDispatcher req=request.getRequestDispatcher("AddProduct.jsp");
		req.forward(request, response);
		}
		
        if(url.equals("/show")) {
        	//showProduct.jsp
            List<Product> myList=service.showProduct();
            request.setAttribute("myProduct", myList);
        	RequestDispatcher req=request.getRequestDispatcher("ShowProduct.jsp");
    		req.forward(request, response);
		}

       
        if(url.equals("/addproduct")) {
        		//fetch the data from AddProduct.jsp
	  String productId=request.getParameter("prodId");
	  String productName=request.getParameter("prodName");
	  String productPrice=request.getParameter("prodPrice");
	  String productOnline=request.getParameter("prodOnline");
	  String productCat=request.getParameter("cato");
	  
	  Product prod=new Product();
	  prod.setId(Integer.parseInt(productId));
	  prod.setName(productName);
	  prod.setPrice(Double.parseDouble(productPrice));
	  prod.setOnline(productOnline);
	  prod.setCategory(productCat);
	  service.addProduct(prod);
	  
	 // request.setAttribute("myProduct", prod);
	  RequestDispatcher res=request.getRequestDispatcher("product.jsp");
	 
	  res.forward(request, response);
	 /* PrintWriter out=response.getWriter();
	//  out.println("<html><head>My Output</head><body>");
	  out.println(" Product Id is "+ productId);
	  out.println(" Product Name is "+ productName);
	  out.println(" Product Price is "+ productPrice);
	  out.println(" Product Online is "+ productOnline);
	  out.println(" Product Category is "+ productCat);
	 */
	 // out.println("</body></html>");
        }
        
 if(url.equals("/search")) {
        	
        	RequestDispatcher req=request.getRequestDispatcher("SearchProduct.jsp"); 
        	req.forward(request, response);
        }
 
 if(url.equals("/searchProduct")) {
	 String Id=request.getParameter("id");
	 int id=Integer.parseInt(Id);
	 Product pro=new Product();
	 pro=service.searchById(id);
	 request.setAttribute("myProduct", pro);
	 
	 RequestDispatcher req=request.getRequestDispatcher("SearchProduct.jsp");
	 req.forward(request, response);
       }
 
 if(url.equals("/update")) {
	 	
	 	RequestDispatcher req=request.getRequestDispatcher("UpdateProduct.jsp"); 
	 	req.forward(request, response);
	 }

	if(url.equals("/updateProduct")) {
	String Id=request.getParameter("id");
	int id=Integer.parseInt(Id);
	Product pro=new Product();
	pro=service.searchById(id);
	request.setAttribute("myProduct", pro);
	String productPrice=request.getParameter("proPrice");
	System.out.println(productPrice);
	
	pro.setPrice(Double.parseDouble(productPrice));

	RequestDispatcher req=request.getRequestDispatcher("UpdateProduct.jsp");
	req.forward(request, response);
	}
	
 if(url.equals("/delete")) {
 	
 	RequestDispatcher req=request.getRequestDispatcher("DeleteProduct.jsp"); 
 	req.forward(request, response);
 }

if(url.equals("/deleteProduct")) {
String Id=request.getParameter("id");
int id=Integer.parseInt(Id);
Product pro=new Product();
pro=service.searchById(id);
request.setAttribute("myProduct", pro);
service.delete(pro);
RequestDispatcher req=request.getRequestDispatcher("DeleteProduct.jsp");
req.forward(request, response);
}
	
	}

}

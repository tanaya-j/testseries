package com.cg.springdemoone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemoone.dto.Item;
import com.cg.springdemoone.dto.Product;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		Product p=(Product) app.getBean("prod");
		/*p.setId(1);
		p.setName("TV");
		p.setPrice(200000.0);
		p.setDescription("4k");*/
//		Item i=(Item) app.getBean("item");
		p.getAllData();
		
//		i.getData();
	}
}

package com.cg.springdemoone.dto;

public class Item {

	private int id;
	private String nameOfShop;
	
	public Item(int id, String nameOfShop) {
		super();
		this.id = id;
		this.nameOfShop = nameOfShop;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNameOfShop() {
		return nameOfShop;
	}

	public void setNameOfShop(String nameOfShop) {
		this.nameOfShop = nameOfShop;
	}

	public Item() {
		System.out.println("Item Constructor..!!");
		}
	
	public void getData() {
		System.out.println("Hi..!!");
	}
}

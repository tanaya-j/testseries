package com.cg.springdemoone.dto;

import java.util.List;

import org.springframework.context.annotation.EnableAspectJAutoProxy;


public class Product {

	private int id;
	private String name;
	private double price;
	private String description;
	private List<Item> item;
	
	public Product() {
		System.out.println("Product Constructor..!!");
	}
	
	
	public Product(int id, String name, double price, String description, List<Item> item) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
		this.item = item;
	}

	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public List<Item> getItem() {
		return item;
	}


	public void setItem(List<Item> item) {
		this.item = item;
	}


	public void getAllData() {
		System.out.println("Id is " + id);
		System.out.println("Name is is " + name);
		System.out.println("Price is " + price);
		System.out.println("Description is " + description);
		
		for(Item it:item) {
		System.out.println("Item is is:" +it.getId());
		System.out.println("shop name is:" +it.getNameOfShop());
	}
	
	} 
	
	
	
	
}

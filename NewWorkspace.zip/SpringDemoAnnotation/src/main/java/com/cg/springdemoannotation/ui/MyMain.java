package com.cg.springdemoannotation.ui;

import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.springdemoannotation.config.JavaConfig;
import com.cg.springdemoannotation.dao.ProductDaoImp;
import com.cg.springdemoannotation.dto.Product;
import com.cg.springdemoannotation.dto.Transaction;
import com.cg.springdemoannotation.service.ProductService;
import com.cg.springdemoannotation.service.ProductServiceImp;

@Component
public class MyMain {
	
	@Autowired
  private ProductService service;
	
private static ProductService serv;
	
	@PostConstruct
	public void init() {
		serv=this.service;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);
		Product myProduct=(Product) app.getBean("product");
	    Transaction transaction= (Transaction) app.getBean("tran");
	    ProductService service=(ProductService) app.getBean("ProductService");
	    
	    myProduct.setId(1);
		myProduct.setName("abc");
		myProduct.setPrice(2222.22);
		myProduct.setDescription("rst");
		
	    transaction.setId(1);
		transaction.setAmount(22222.2);
		transaction.setDescription("hsdjh");
		
      //	myProduct.getAllData();
	  //	System.out.println(myProduct);

	//	ProductService service=new ProductServiceImp();
		service.addProduct(myProduct);
		System.out.println(service.showAll());
		}
}

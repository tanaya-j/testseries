package com.cg.springdemoannotation.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springdemoannotation.dto.Product;

@Repository("productDao")
public class ProductDaoImp implements ProductDao{
List<Product> productList=new ArrayList<Product>();
	
ProductDaoImp(){
	System.out.println("h");
}

 
    public void save(Product pro) {
		// TODO Auto-generated method stub
		productList.add(pro);
	}

	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productList;
	}

}

package com.cg.springdemoannotation.dao;

import java.util.List;
import com.cg.springdemoannotation.dto.Product;


public interface ProductDao {
    public void save(Product pro);
	public List<Product> showAll();
}

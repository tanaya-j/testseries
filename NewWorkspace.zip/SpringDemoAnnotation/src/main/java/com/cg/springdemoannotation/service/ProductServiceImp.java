package com.cg.springdemoannotation.service;

import java.util.List;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.springdemoannotation.dao.ProductDao;
import com.cg.springdemoannotation.dao.ProductDaoImp;
import com.cg.springdemoannotation.dto.Product;

@Service("ProductService")
public class ProductServiceImp implements ProductService {

   
	@Autowired
	ProductDao productDao;
//	
//	@PostConstruct
	/*public void init() {
		System.out.println("abc");
	}*/
	
	/*public ProductServiceImp(ProductDao productdao) {
	
	}*/
	
	public void addProduct(Product prod) {
		// TODO Auto-generated method stub
		productDao.save(prod);
	}

	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return  productDao.showAll();
	}
}

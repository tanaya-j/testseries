package com.cg.springdemoannotation.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.springdemoannotation.dto.Product;
import com.cg.springdemoannotation.dto.Transaction;

@Configuration
@ComponentScan("com.cg.springdemoannotation")
public class JavaConfig {

	/*@Bean(name="product",autowire=Autowire.BY_TYPE)
	
	public Product getProduct() {
		Product pro=new Product();
		pro.setId(1);
		pro.setName("TV");
		pro.setPrice(222222.0);
		pro.setDescription("4K");
		
		return pro;
	}
	
	@Bean(name="tran")
	public Transaction getTransaction() {
		Transaction tran=new Transaction();
		tran.setId(1);
		tran.setDescription("For product id 1");
		tran.setAmount(22222.2);
		return tran;
	}
	
	@Bean(name="trana")
	public Transaction getTransactionO() {
		Transaction tran1=new Transaction();
		tran1.setId(2);
		tran1.setDescription("For product id 2");
		tran1.setAmount(22222.2);
		return tran1;}*/
	
}

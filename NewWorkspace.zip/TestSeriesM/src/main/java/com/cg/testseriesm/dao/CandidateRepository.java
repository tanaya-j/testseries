package com.cg.testseriesm.dao;

import com.cg.testseriesm.dto.Candidate;

/* This is a candidate repository interface which includes methods of saving candidates to the database
 * and finding candidate by Id  */
public interface CandidateRepository {
	public Candidate saveCandidate(Candidate candidate);
	public Candidate findById(int id);
}

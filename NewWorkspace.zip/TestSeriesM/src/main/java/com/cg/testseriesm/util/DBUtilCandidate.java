package com.cg.testseriesm.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.testseriesm.dto.Candidate;

public class DBUtilCandidate {
	public static List<Candidate> myCandidates=new ArrayList<Candidate>();
}

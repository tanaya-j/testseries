package com.cg.testseriesm.exception;

public class TestNotFoundException extends RuntimeException {

	 public TestNotFoundException() {
		
	}
	
     public  TestNotFoundException(String msg) {
		super(msg);
	}
}

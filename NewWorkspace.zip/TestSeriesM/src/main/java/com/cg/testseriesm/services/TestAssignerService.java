package com.cg.testseriesm.services;

import com.cg.testseriesm.dto.Assigner;


/*
 * This is the test assigner interface which includes method that assigns test to candidate
 * */
public interface TestAssignerService {
	public Assigner assignTestToCandidate(Assigner assigner);
	
}

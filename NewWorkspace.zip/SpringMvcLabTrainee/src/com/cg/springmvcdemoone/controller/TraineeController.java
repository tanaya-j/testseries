package com.cg.springmvcdemoone.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.cg.springmvcdemoone.dto.Trainee;
import com.cg.springmvcdemoone.service.TraineeService;
@Controller
public class TraineeController {

	@Autowired
	TraineeService traineeService;
	//@RequestMapping(name="login", method=RequestMethod.GET)
	@GetMapping(value="login")
	public String loginPage() {
		return "mylogin";
		
	}
	
	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		System.out.println("in check login....");
		
		if(user.equals("admin") && pass.equals("123456")) {
			return "listpage";
		}
		else {
			return "error";
		}
		//return null;
		
		}
	@GetMapping("addpage")
	public ModelAndView addTrainee(@ModelAttribute("train") Trainee tran, Model model) {
		List<String> listofDomain= new ArrayList<>();
		listofDomain.add("java trainer");
		listofDomain.add("javascript trainer");
		listofDomain.add("sql trainer");
		addRadio(model);
		return new ModelAndView("add", "dom", listofDomain);
		
	}
	
	@GetMapping("retrieveAllpage")
	public ModelAndView showTrainee() {
		List<Trainee> traineeList = traineeService.showAll();
		return new ModelAndView("showTrainee", "key1", traineeList);
	}
	
	@PostMapping("addtrainee")
	public ModelAndView addTrainee(@ModelAttribute("train") Trainee t) {
		//System.out.println(pro);
		Trainee trainee=traineeService.addTrainee(t);
		return new ModelAndView("listpage", "key", trainee);					//all the values is stored in key of product and passed to success.jsp
	} 
	
	@GetMapping("searchpage")
	public ModelAndView search() {
		return new ModelAndView("retrieveTrainee");
	}
	
	@PostMapping("retrieve")
	public ModelAndView searchTrainee(@RequestParam("id") int id,Model model) {
	Trainee t=traineeService.searchById(id);
	model.addAttribute("keyy",t);
	return new ModelAndView("retrieveTrainee");
			}
	
	
	
	@GetMapping("deletepage")
	public ModelAndView delete() {
		return new ModelAndView("delete");
	}
	
	@PostMapping("delete")
	public ModelAndView deletetraineee(@RequestParam("id") int id ,Model m) {
		Trainee trr=traineeService.searchById(id);
		m.addAttribute("del", id);
		traineeService.delete(trr);
		return new ModelAndView("delete");
	}
	
	@GetMapping("modifypage")
	public ModelAndView update() {
		return new ModelAndView("update");
	}
	
  
	@PostMapping("update")
	public ModelAndView updateProduct(@RequestParam("tid") int id,@RequestParam("name") String name,@RequestParam("location") String location,
		@RequestParam("domain") String domain,Model m)
			{  
			Trainee traa= traineeService.update(id);				
			m.addAttribute("comm", traa);
			//prod.setPrice(price);
			traa.setName(name);
			traa.setLocation(location);
			traa.setDomain(domain);
			return new ModelAndView("update");
			} 
		 

	
	public void addRadio(Model model) {
	List<String> locationList = new ArrayList<String>();
	locationList.add("Chennai");
	locationList.add("Bangalore");
	locationList.add("Pune");
	locationList.add("Mumbai");
    model.addAttribute("locations", locationList);
	}
}

package com.cg.springmvcdemoone.dao;

import java.util.List;

import com.cg.springmvcdemoone.dto.Trainee;

public interface TraineeDao {

	public Trainee save(Trainee trainee);
	public Trainee findById(int id);
	public void delete(Trainee trainee);

	public List<Trainee> showAll();
}

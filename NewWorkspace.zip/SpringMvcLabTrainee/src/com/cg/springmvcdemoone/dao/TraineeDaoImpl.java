package com.cg.springmvcdemoone.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemoone.dto.Trainee;


@Repository
public class TraineeDaoImpl implements TraineeDao {

	List<Trainee> traineeList = new ArrayList<>();
	@Override
	public Trainee save(Trainee trainee) {
		// TODO Auto-generated method stub
		traineeList.add(trainee);
		return trainee;
	}

	@Override
	public List<Trainee> showAll() {
		// TODO Auto-generated method stub
		return traineeList;
	}

	@Override
	public Trainee findById(int id) {
		// TODO Auto-generated method stub
		for(Trainee t:traineeList) {
		if(t.getId()==id) {
			
				return  t;
			}}
			return null;
	}

	

	@Override
	public void delete(Trainee trainee) {
		// TODO Auto-generated method stub
		 traineeList.remove(trainee);
	}

	

}

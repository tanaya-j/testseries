package com.cg.springmvcdemoone.service;

import java.util.List;

import com.cg.springmvcdemoone.dto.Trainee;

public interface TraineeService {

	public Trainee addTrainee(Trainee trainee);
	public Trainee searchById(int id);
	public List<Trainee> showAll();
	public Trainee update(int id);
	public void delete(Trainee trainee);
}

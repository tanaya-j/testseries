package com.cg.springmvcdemoone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemoone.dao.TraineeDao;
import com.cg.springmvcdemoone.dto.Trainee;

@Service
public class TraineServiceImpl implements TraineeService {

	@Autowired
	TraineeDao traineeDao;
	@Override
	public Trainee addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineeDao.save(trainee);
	}

	@Override
	public List<Trainee> showAll() {
		// TODO Auto-generated method stub
		return traineeDao.showAll();
	}

	@Override
	public Trainee searchById(int id) {
		// TODO Auto-generated method stub
		return traineeDao.findById(id);
	}

	@Override
	public Trainee update(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Trainee trainee) {
		// TODO Auto-generated method stub
		traineeDao.delete(trainee);
	}

}

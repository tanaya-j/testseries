package com.cg.demomvcjavaconfig.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Product;

@Repository
public class ProductRepositoryImp implements ProductRepository {

	
	List<Product> myList=new ArrayList<>();
	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		myList.add(product);
		return product;
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return myList;
	}

}

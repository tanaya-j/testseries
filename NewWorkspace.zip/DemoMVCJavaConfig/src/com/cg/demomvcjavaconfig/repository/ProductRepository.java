package com.cg.demomvcjavaconfig.repository;

import java.util.List;

import com.cg.demomvcjavaconfig.dto.Product;



public interface ProductRepository {
	
	public Product saveProduct(Product product);
	public List<Product> showProduct();
}

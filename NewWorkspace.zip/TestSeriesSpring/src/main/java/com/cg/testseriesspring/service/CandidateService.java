package com.cg.testseriesspring.service;

import java.util.List;

import com.cg.testseriesspring.dto.Candidate;
/*This a candidate service interface which includes add candidates and searchBy  id method
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */
public interface CandidateService {

	  public Candidate addCandidate(Candidate candidate);
      public Candidate searchById(int id);
}

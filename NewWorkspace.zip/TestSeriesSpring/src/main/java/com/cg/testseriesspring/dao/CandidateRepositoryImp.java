package com.cg.testseriesspring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.testseriesspring.util.DBUtilCandidate;
import com.cg.testseriesspring.exception.CandidateNotFoundException;
import com.cg.testseriesspring.dto.Candidate;
/*
 * This is a implementation of candidate repository which implements 
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
*/
@Repository("CandidateRepository")
public class CandidateRepositoryImp implements CandidateRepository {

	
	
/*saves the candidate
	 * @param: candidate
	 * @return: candidate
	 * last Modified 15/05/2019  Author:Tanaya Jadhav
*/
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		DBUtilCandidate.myCandidates.add(candidate);
		return candidate;
	}
	
	
/*finds the candidate
	 * @param: id
	 * @return: candidate
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		for (Candidate candidate : DBUtilCandidate.myCandidates) 
			if(candidate.getId()==id) {
			
				return  candidate;
			}
			return null;
	}
	
}


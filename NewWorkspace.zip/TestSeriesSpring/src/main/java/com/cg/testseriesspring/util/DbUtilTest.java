package com.cg.testseriesspring.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.testseriesspring.dto.Question;
import com.cg.testseriesspring.dto.Test;


public class DbUtilTest {

//	public static Map<String,Test> myTests=new HashMap<String,Test>();
	public static List<Test> myTestList=new ArrayList<Test>();
	public static List<Question> myQuestionList=new ArrayList<Question>();
}

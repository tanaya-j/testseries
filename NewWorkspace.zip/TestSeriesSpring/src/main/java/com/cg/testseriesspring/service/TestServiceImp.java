package com.cg.testseriesspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesspring.dao.TestRepository;
import com.cg.testseriesspring.dao.TestRepositoryImp;
import com.cg.testseriesspring.dto.Test;
import com.cg.testseriesspring.exception.TestNotFoundException;

/*This class is implementation of test service interface which implements create test ,search test 
 * by name  methods..!
 * last Modified 15/05/2019 Author:Tanaya Jadhav 
*/
@Service("TestService")
public class TestServiceImp implements TestService{

	@Autowired
	TestRepository dao;
	
/*creates test
	 * @param: Test
	 * @return: test
	 last Modified 15/05/2019  Author:Tanaya Jadhav
*/
	public Test createMyTest(Test test) {
		// TODO Auto-generated method stub
		return dao.saveTest(test);
	}


/*searches test by name
	 * @param: testname
	 * @return: test with that name 
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Test searchTestByName(String testName) {
		// TODO Auto-generated method stub
		Test t=dao.findByName(testName);
		if(t==null) {
			throw new TestNotFoundException("Test is not created");
		}
		return t;
	}
	
}

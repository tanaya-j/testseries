package com.cg.testseriesspring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/*
 * This is configuration class which is used for bean creation which falls under same package
 * last Modified 15/05/2019
* Author:Tanaya Jadhav */

@Configuration
@ComponentScan("com.cg.testseriesspring")
public class JavaConfig {
}

package com.cg.testseriesspring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.testseriesspring.util.DbUtilTest;
import com.cg.testseriesspring.exception.TestNotFoundException;
import com.cg.testseriesspring.dto.Test;

/*This class implements the test repository interface  It includes create test and find by name methods
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 */


@Repository("TestRepository")
public class TestRepositoryImp implements TestRepository{

	
/*this method saves the test
	 * @param: test
	 * @return: test 
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Test saveTest(Test test) {
		// TODO Auto-generated method stub
		DbUtilTest.myTestList.add(test);
		return test;
	}


/*this method finds the test by name
	 * @param: testname
	 * @return: test 
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Test findByName(String testName) {
		// TODO Auto-generated method stub
		for(Test myTestName: DbUtilTest.myTestList)
			if(myTestName.getName().equals(testName)) {
				return myTestName;
			}
			
	      	return null;
	}
}

package com.cg.testseriesspring.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.testseriesspring.util.DBUtilAssigner;
import com.cg.testseriesspring.dto.Assigner;
import com.cg.testseriesspring.dto.Candidate;
import com.cg.testseriesspring.dto.Test;
/*
 * This class implements the test assigner repository interface
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 */
@Repository("AssignerRepository")
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	
/*saves the assigner  @param: assigner
	 * @return: assigner
	 * last Modified 15/05/2019 Author:Tanaya Jadhav
*/
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
		 DBUtilAssigner.assigner.add(assigner);
			return assigner;
	}
}

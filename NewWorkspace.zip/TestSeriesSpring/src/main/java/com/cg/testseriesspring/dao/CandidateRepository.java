package com.cg.testseriesspring.dao;

import java.util.List;

import com.cg.testseriesspring.dto.Candidate;
/* This is a candidate repository interface which includes methods of saving candidates to the database
 * and finding candidate by Id 
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav  */
public interface CandidateRepository {

	public Candidate saveCandidate(Candidate candidate);
	public Candidate findById(int id);
}

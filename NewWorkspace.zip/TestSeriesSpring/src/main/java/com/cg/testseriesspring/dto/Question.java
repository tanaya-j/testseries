package com.cg.testseriesspring.dto;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
/*
 * This is bean class for Question it includes int number, String content ,String optionA ,
 * String optionB, String optionC,String correct option
 * Constructor,getter setter ,toString is defined
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav */
@Component("Question")
@Scope("prototype")
public class Question {
	private int number;
	private String content;
	private String  optionA;
	private String  optionB;
	private String  optionC;
	private String correctOption;
	
	public Question() {}

	
	public Question(int number, String content, String optionA, String optionB, String optionC, String correctOption) {
		super();
		this.number = number;
		this.content = content;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.correctOption = correctOption;
	}


	public int getNumber() {
		return number;
	}


	public void setNumber(int number) {
		this.number = number;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getOptionA() {
		return optionA;
	}


	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}


	public String getOptionB() {
		return optionB;
	}


	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}


	public String getOptionC() {
		return optionC;
	}


	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}


	public String getCorrectOption() {
		return correctOption;
	}


	public void setCorrectOption(String correctOption) {
		this.correctOption = correctOption;
	}


	@Override
	public String toString() {
		return "Question [number=" + number + ", content=" + content + ", optionA=" + optionA + ", optionB=" + optionB
				+ ", optionC=" + optionC + ", correctOption=" + correctOption + "]";
	}


}
	
	


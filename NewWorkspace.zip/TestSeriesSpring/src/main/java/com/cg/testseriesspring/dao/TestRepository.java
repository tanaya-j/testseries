package com.cg.testseriesspring.dao;

import java.util.List;

import com.cg.testseriesspring.dto.Test;


/*
 * This is a test repository interface it includes save test and find by name methods
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 * */
public interface TestRepository {
	public Test saveTest(Test test);//saves test
	public Test findByName(String testName);//finds test
}

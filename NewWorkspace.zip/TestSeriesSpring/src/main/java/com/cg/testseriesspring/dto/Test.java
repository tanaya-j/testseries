package com.cg.testseriesspring.dto;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/*
 * This is bean class for Test it includes name(String),total questions(BigInteger),total marks(BigInteger),
 * list of questions
 * Constructor,getter setter ,toString is defined
 * last Modified 15/05/2019
 * Author:Tanaya Jadhav 
 * */
@Component("Test")
@Scope("prototype")
public class Test {
	private String name;
	private BigInteger totalquestions;
	private BigInteger totalMarks;
	
	private List<Question> questions;
	
	public Test() {}

	public Test(String name, BigInteger totalquestions, BigInteger totalMarks, List<Question> questions) {
		super();
		this.name = name;
		this.totalquestions = totalquestions;
		this.totalMarks = totalMarks;
		this.questions = questions;
	}

	public String getName() {
		return name;
	}

	public void setName(String testName) {
		this.name = testName;
	}

	public BigInteger getTotalquestions() {
		return totalquestions;
	}

	public void setTotalquestions(BigInteger totalquestions) {
		this.totalquestions = totalquestions;
	}

	public BigInteger getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(BigInteger totalMarks) {
		this.totalMarks = totalMarks;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "Test [Name=" + name + ", totalquestions=" + totalquestions + ", totalMarks=" + totalMarks
				+ ", questions=" + questions + "]";
	}

	
	
}


package com.cg.testseriesspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.testseriesspring.dao.TestAssignerRepository;
import com.cg.testseriesspring.dao.TestAssignerRepositoryImp;
import com.cg.testseriesspring.dto.Assigner;
import com.cg.testseriesspring.dto.Candidate;
import com.cg.testseriesspring.dto.Test;

/*
 * This class implements the test assigner service interface
 * last Modified 15/05/2019 Author:Tanaya Jadhav 
*/

@Service("TestAssignerService")
public class TestAssignerServiceImp implements TestAssignerService{

	@Autowired
	TestAssignerRepository assignerDao;
	
	

/* This method assigns the test 
 * @param: assigner
 * @return: assigner   last Modified 15/05/2019  Author:Tanaya Jadhav
*/
	public Assigner assignTestToCandidate(Assigner assigner) {
		// TODO Auto-generated method stub
		return assignerDao.save(assigner);
	}
}

package com.cg.springmvcdemoone.dao;

import java.util.List;

import com.cg.springmvcdemoone.dto.Product;

public interface ProductRepository {

	
	public Product saveProduct(Product product);
	public List<Product> showProduct();
	
}

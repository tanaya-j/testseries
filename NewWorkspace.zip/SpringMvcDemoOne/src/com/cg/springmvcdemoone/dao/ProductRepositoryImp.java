package com.cg.springmvcdemoone.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemoone.dto.Product;


@Repository
public class ProductRepositoryImp implements ProductRepository{

	List<Product> myProducts=new ArrayList<Product>();
	
	
	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		myProducts.add(product);
		return product;
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return myProducts;
	}

}

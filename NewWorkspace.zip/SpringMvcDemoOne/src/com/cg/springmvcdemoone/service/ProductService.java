package com.cg.springmvcdemoone.service;

import java.util.List;

import com.cg.springmvcdemoone.dto.Product;

public interface ProductService {

	public Product addProduct(Product product);
	public List<Product> showProduct();
	
}

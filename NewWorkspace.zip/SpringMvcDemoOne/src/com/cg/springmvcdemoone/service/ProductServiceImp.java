package com.cg.springmvcdemoone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemoone.dao.ProductRepository;
import com.cg.springmvcdemoone.dto.Product;

@Service
public class ProductServiceImp implements ProductService{

	@Autowired
	ProductRepository dao;
	
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.saveProduct(product);
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return dao.showProduct();
	}

}

package com.cg.springmvcdemoone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemoone.dto.Product;
import com.cg.springmvcdemoone.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;
	
	// @RequestMapping(name="login",method=RequestMethod.GET)
	 @GetMapping(value="login")
	 public String loginPage() {
		 return "mylogin";
	 }

	 @PostMapping("checkLogin")
     public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		// System.out.println("check login");
		 if(user.equals("admin") && pass.equals("tanaya")) {
			 return "listpage";
		 }else {
			 return "error";
		 }
		// return null;
	 }
	 
	 @GetMapping("addpage")
	 public ModelAndView getAddproduct(@ModelAttribute("prod") Product pro) {
		 List<String> listOfCategory=new ArrayList<>();
		 listOfCategory.add("Electronics");
		 listOfCategory.add("Book");
		 listOfCategory.add("Cosmetics");
		// map.put("cato",listOfCategory);,Map<String,Object> map
		 return new ModelAndView("addproduct", "cato", listOfCategory);
	 }
	 
	 @GetMapping("showpage")
	 public ModelAndView showProduct() {
		 List<Product> myProducts = productService.showProduct();
		 return new ModelAndView("showAll", "showproduct", myProducts);
	 }
	 
	 
	 @PostMapping("addproduct")
	 public ModelAndView addproduct(@ModelAttribute("prod") Product pro) {
//		 System.out.println(pro);
		Product product= productService.addProduct(pro);
		 return new ModelAndView("success","key",product);
	 }
	 
	 
	
}

package com.cg.testseriesjpa.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * This a Candidate bean class with the attributes as id,name
 * Parameterized constructor , getter setters and toString methods..!*/

@Entity
@Table(name="Candidate")
public class Candidate {
	   @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
	   @Column(name="candidate_id")
	   private int id;//primary key
	   @Column(name="Name")
	   private String name;
    
  
  public Candidate() {}

	public Candidate( String name) {
		super();
	
		this.name = name;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	@Override
	public String toString() {
		return "Candidate [Id=" + id + ", name=" + name +  "]";
	}
  
}

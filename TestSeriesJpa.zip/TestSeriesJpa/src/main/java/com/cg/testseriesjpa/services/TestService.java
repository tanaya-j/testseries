package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dto.Test;

/*
 * This a test interface it includes methods for creating test ,searching test by name and Id*/
public interface TestService {
	public void createMyTest(Test test);
	public Test searchTestByName(String testName);
	public Test searchTestById(int id);
}

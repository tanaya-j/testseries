package com.cg.testseriesjpa.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.testseriesjpa.dto.Candidate;
import com.cg.testseriesjpa.dto.Test;
/*
 * This a Assigner bean class with the attributes as id,date,test(Object of class Test),candidate(Object of
 *  class candidate).
 * Parameterized constructor , getter setters and toString methods..!*/

@Entity
@Table(name="Assigner")
public class Assigner {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	    private int id;//primary key
	@Column(name="Date")
	    private	Date date;
	@OneToOne
	@JoinColumn(name="test_id")
		private Test test;
	@OneToOne
	@JoinColumn(name="candidate_id")
		private Candidate candidate;
		
		public Assigner() {}

		public Assigner( Date date, Test test, Candidate candidate) {
			super();
		
			this.date = date;
			this.test = test;
			this.candidate = candidate;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public Test getTest() {
			return test;
		}

		public void setTest(Test test) {
			this.test = test;
		}

		public Candidate getCandidate() {
			return candidate;
		}

		public void setCandidate(Candidate candidate) {
			this.candidate = candidate;
		}

		@Override
		public String toString() {
			return "Assigner [id=" + id + ", date=" + date + ", test=" + test + ", candidate=" + candidate + "]";
		}
		
		
		
}

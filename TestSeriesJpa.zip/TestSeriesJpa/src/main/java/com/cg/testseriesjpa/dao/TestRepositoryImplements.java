package com.cg.testseriesjpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import com.cg.testseriesjpa.dto.Question;
import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.TestNotFoundException;
import com.cg.testseriesjpa.util.DbUtil;

public class TestRepositoryImplements implements TestRepository {
EntityManager em;
	public TestRepositoryImplements() {
		em=DbUtil.getConnection();
	}
	//saves the created test in the database
	public void saveTest(Test test) {
		// TODO Auto-generated method stub
	em.merge(test);
	em.getTransaction().commit();
	
		
		
		
	}
	public Test findByName(String testName) {
		// TODO Auto-generated method stub
		
		return null;
	}
	public Test findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
		


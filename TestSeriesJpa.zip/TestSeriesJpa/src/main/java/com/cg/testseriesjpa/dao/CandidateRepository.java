package com.cg.testseriesjpa.dao;

import com.cg.testseriesjpa.dto.Candidate;

/* This is a candidate repository interface which includes methods of saving candidates to the database
 * and finding candidate by Id  */
public interface CandidateRepository {
	public void saveCandidate(Candidate candidate);
	public Candidate findById(int id);
}
